#!/usr/bin/env bash

# sudo check

if [[ "$EUID" -ne 0 ]]; then
  echo "This script must be run as root. Use: sudo $0"
  exit 1
fi

# packages

usermod -aG i2c orangepi
apt update
apt install -y sqlite3 python3-smbus2 python3-serial python3-pip python3-pil python3-smbus2 hostapd dnsmasq iptables
rm /usr/lib/python3.12/EXTERNALLY-MANAGED
sudo -u orangepi python3 -m pip install bleak

# make executable
chmod +x /home/orangepi/code/*.sh
chmod +x /home/orangepi/code/*.py

# service

mkdir /var/log/master
chmod o+wx /var/log/master
cp /home/orangepi/code/emaster.service /etc/systemd/system/
cp /home/orangepi/code/edisplay.service /etc/systemd/system/
cp /home/orangepi/code/epass.service /etc/systemd/system/
cp /home/orangepi/code/enet.service /etc/systemd/system/

systemctl daemon-reload

systemctl start emaster.service
systemctl enable emaster.service
systemctl start edisplay.service
systemctl enable edisplay.service
systemctl start epass.service
systemctl enable epass.service
systemctl start enet.service
systemctl enable enet.service

(crontab -l 2>/dev/null; echo '@reboot sleep 30 && /home/orangepi/code/init_ap.sh >> /var/log/ap.log 2>&1') | crontab -

/home/orangepi/code/init_ap.sh
