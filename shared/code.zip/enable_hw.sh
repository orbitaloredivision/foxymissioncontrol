#!/usr/bin/env bash
set -euo pipefail

SIG_FILE="/boot/update.sig"
ENV_FILE="/boot/orangepiEnv.txt"
NEEDED=("ph-i2c3" "ph-uart5")

if [[ $EUID -ne 0 ]]; then
  echo "Run as root: sudo $0"
  exit 1
fi

if [ -f "$SIG_FILE" ]; then
  echo "Already up-to-date"
  exit 0
fi

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE not found"
  exit 1
fi

sudo bash -lc '
set -euo pipefail

LOG=/var/log/u-boot-install.log
exec >>"$LOG" 2>&1
echo "=== $(date -Is) u-boot install start ==="

if [[ ! -f /usr/lib/u-boot/platform_install.sh ]]; then
  echo "ERROR: /usr/lib/u-boot/platform_install.sh not found"
  exit 1
fi

source /usr/lib/u-boot/platform_install.sh

root_uuid=$(sed -e "s/^.*root=//" -e "s/ .*$//" < /proc/cmdline)
echo "root_uuid=$root_uuid"

root_partition=$(blkid | tr -d "\" :" | grep "$root_uuid" | awk "{print \$1}" | head -n 1)
echo "root_partition=$root_partition"

root_partition_device="${root_partition::-2}"
echo "root_device=$root_partition_device"

# DIR is usually something like /usr/lib/u-boot/<platform>/ or a temp dir in orangepi-config.
# If platform_install.sh defines a default, prefer that. Otherwise guess /usr/lib/u-boot.
DIR=${DIR:-/usr/lib/u-boot}
echo "DIR=$DIR"

write_uboot_platform "$DIR" "$root_partition_device"

echo "=== $(date -Is) u-boot install done"
'

# Read current overlays= line (if any)
current="$(grep -E '^overlays=' "$ENV_FILE" | head -n1 | cut -d= -f2- || true)"

# Build a unique list: existing + needed
new="$current"
for o in "${NEEDED[@]}"; do
  if [[ " $new " != *" $o "* ]]; then
    new="${new:+$new }$o"
  fi
done

# If overlays= exists -> replace; else -> append
if grep -qE '^overlays=' "$ENV_FILE"; then
  sed -i -E "s|^overlays=.*|overlays=$new|" "$ENV_FILE"
else
  printf "\noverlays=%s\n" "$new" >> "$ENV_FILE"
fi

echo "Updated $ENV_FILE:"
grep -E '^overlays=' "$ENV_FILE"

echo "1" > $SIG_FILE

echo "Reboot required to apply DT overlays. Rebooting now...."
reboot
