#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import random
import re
import socket
import sys
import time
from urllib.parse import urlparse, unquote


RTSP_EOL = "\r\n"


def jprint(result: bool, error: str = "", **extra):
    out = {"result": bool(result), "error": error}
    out.update(extra)
    print(json.dumps(out, ensure_ascii=False))
    return 0 if result else 1


def parse_rtsp_url(url: str):
    p = urlparse(url)

    if p.scheme.lower() != "rtsp":
        raise ValueError("URL must start with rtsp://")

    if not p.hostname:
        raise ValueError("Missing host")

    host = p.hostname
    port = p.port if p.port else 554

    if p.username is None or p.password is None:
        raise ValueError("Missing user or password in URL")

    user = unquote(p.username)
    password = unquote(p.password)

    path = p.path or "/"
    if p.query:
        path = f"{path}?{p.query}"

    uri_no_creds = f"rtsp://{host}:{port}{path}"

    return {
        "user": user,
        "password": password,
        "host": host,
        "port": port,
        "path": path,
        "uri": uri_no_creds,
    }


def tcp_connect(host: str, port: int, timeout: float):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect((host, port))
    return s


def recv_all(sock: socket.socket, timeout: float, max_bytes: int = 128 * 1024) -> bytes:
    """
    Read headers + body (best effort).
    """
    sock.settimeout(timeout)
    data = bytearray()
    while True:
        try:
            chunk = sock.recv(4096)
        except socket.timeout:
            break
        if not chunk:
            break
        data += chunk
        if len(data) > max_bytes:
            break
    return bytes(data)


def parse_status_headers_body(resp: bytes):
    """
    Returns (status_code, headers_dict, body_bytes)
    """
    parts = resp.split(b"\r\n\r\n", 1)
    head = parts[0].decode("utf-8", errors="replace")
    body = parts[1] if len(parts) > 1 else b""

    lines = head.split("\r\n")
    m = re.match(r"RTSP/\d\.\d\s+(\d{3})", lines[0])
    status = int(m.group(1)) if m else None

    headers = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()

    return status, headers, body


def detect_codec(sdp_body: bytes) -> str:
    """
    Detect codec from SDP body.
    """
    text = sdp_body.decode("utf-8", errors="ignore").upper()

    if "H265" in text or "HEVC" in text:
        return "h265"
    if "H264" in text or "AVC" in text:
        return "h264"

    return "unknown"


def build_request(method: str, uri: str, cseq: int, headers: dict) -> bytes:
    lines = [f"{method} {uri} RTSP/1.0", f"CSeq: {cseq}"]
    for k, v in headers.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("")
    return RTSP_EOL.join(lines).encode("utf-8")


def parse_www_authenticate(hval: str):
    if not hval:
        return None, {}

    if hval.lower().startswith("digest"):
        scheme = "digest"
        params_str = hval[len("digest"):].strip()
    elif hval.lower().startswith("basic"):
        scheme = "basic"
        params_str = hval[len("basic"):].strip()
    else:
        return None, {}

    params = {}
    for m in re.finditer(r'(\w+)=("([^"]*)"|([^\s,]+))', params_str):
        key = m.group(1)
        val = m.group(3) if m.group(3) else m.group(4)
        params[key] = val

    return scheme, params


def md5_hex(s: str) -> str:
    return hashlib.md5(s.encode("utf-8")).hexdigest()


def make_basic_auth(user: str, password: str) -> str:
    import base64
    token = base64.b64encode(f"{user}:{password}".encode()).decode()
    return f"Basic {token}"


def make_digest_auth(user, password, method, uri, params):
    realm = params.get("realm", "")
    nonce = params.get("nonce", "")
    qop = params.get("qop", "")

    ha1 = md5_hex(f"{user}:{realm}:{password}")
    ha2 = md5_hex(f"{method}:{uri}")

    if qop:
        nc = "00000001"
        cnonce = md5_hex(str(random.random()))[:16]
        resp = md5_hex(f"{ha1}:{nonce}:{nc}:{cnonce}:auth:{ha2}")
        return (
            f'Digest username="{user}", realm="{realm}", nonce="{nonce}", '
            f'uri="{uri}", response="{resp}", qop=auth, nc={nc}, cnonce="{cnonce}"'
        )

    resp = md5_hex(f"{ha1}:{nonce}:{ha2}")
    return (
        f'Digest username="{user}", realm="{realm}", nonce="{nonce}", '
        f'uri="{uri}", response="{resp}"'
    )


def rtsp_check(url: str, timeout: float = 5.0):
    info = parse_rtsp_url(url)

    sock = tcp_connect(info["host"], info["port"], timeout)
    with sock:
        cseq = 1

        # First DESCRIBE (no auth)
        req = build_request(
            "DESCRIBE",
            info["uri"],
            cseq,
            {"Accept": "application/sdp"}
        )
        sock.sendall(req)
        resp = recv_all(sock, timeout)

    status, headers, body = parse_status_headers_body(resp)

    if status == 200:
        return True, "", detect_codec(body), "none"

    if status == 401:
        www = headers.get("www-authenticate", "")
        scheme, params = parse_www_authenticate(www)

        if scheme is None:
            return False, "Auth required but unknown scheme", "unknown", ""

        # Build auth header
        if scheme == "basic":
            auth = make_basic_auth(info["user"], info["password"])
        else:
            auth = make_digest_auth(info["user"], info["password"], "DESCRIBE", info["uri"], params)

        # Retry with auth
        sock2 = tcp_connect(info["host"], info["port"], timeout)
        with sock2:
            req2 = build_request(
                "DESCRIBE",
                info["uri"],
                2,
                {"Accept": "application/sdp", "Authorization": auth}
            )
            sock2.sendall(req2)
            resp2 = recv_all(sock2, timeout)

        status2, headers2, body2 = parse_status_headers_body(resp2)

        if status2 == 200:
            return True, "", detect_codec(body2), scheme
        if status2 == 401:
            return False, "Unauthorized (bad login/password)", "unknown", scheme

        return False, f"Unexpected RTSP status {status2}", "unknown", scheme

    return False, f"Unexpected RTSP status {status}", "unknown", ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url", help="rtsp://user:pass@host:port/path")
    ap.add_argument("--timeout", type=float, default=5.0)
    args = ap.parse_args()

    try:
        ok, err, codec, auth = rtsp_check(args.url, timeout=args.timeout)
    except Exception as e:
        return jprint(False, str(e))

    if ok:
        return jprint(True, "", codec=codec, auth=auth)

    return jprint(False, err, codec=codec, auth=auth)


if __name__ == "__main__":
    sys.exit(main())
