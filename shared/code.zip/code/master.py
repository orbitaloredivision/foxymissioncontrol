#!/usr/bin/python3

import os
import sys
import time
import math
import sqlite3
import json
import struct
import threading
import serial, time, socket
import subprocess
import re
import ipaddress
import concurrent.futures as cf
import datetime as dt
from pathlib import Path
from enum import IntEnum
from typing import List, Sequence, Optional

DB_PATH = "/home/orangepi/code/telemetry.db"
TARGETS_PATH = "/home/orangepi/guidashboard/drone-profiles.json"
CONSOLE_TARGET_PATH = "/dev/shm/active"

DRONE_TYPE_FOXY = 'foxy'
DRONE_TYPE_VOLYA = 'volya'
DEFAULT_DRONE_TYPE = DRONE_TYPE_FOXY

UDP_PORT     = 1091
UART_PORTS   = ['/dev/ttyS5', '/dev/ttyAS5']
UART_PORT    = None
UART_BAUD    = 115200
TARGET_PORT  = 1091
PREFIX_BYTE  = b'\x69'

TARGETS = None
TARGETS_TIME = None
ACTIVE_TARGET = 0
TARGET_IP     = None
targets_lock     = threading.Lock()
switch_elrs_target_time = None
switch_console_target_time = None

elrs_p_target = None

COPY_IP    = '10.8.0.8'

ELRS_FILE = '/dev/shm/elrs'
SLAVE_FILE = '/dev/shm/slave'
HB_FILE  = '/dev/shm/hb_'

TELEMETRY_LIFETIME_HR = 6
CLEANUP_INTERVAL = 3600  # seconds (1 hour)
_last_cleanup = 0

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS telemetry (
    ID        INTEGER PRIMARY KEY AUTOINCREMENT,
    drone_id  INTEGER NOT NULL,
    active    INTEGER NOT NULL CHECK (active IN (0, 1)),
    timestamp INTEGER NOT NULL,         -- Unix timestamp (UTC)
    data      TEXT    NOT NULL          -- JSON string
);
"""

INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_telemetry_timestamp
ON telemetry(timestamp);
"""

ser = None
last_gps_lat = 0
last_gps_lng = 0
last_dm = "STOP"
last_speed = 0
last_dist = 0
is_calib_mode = False
CAMERA_IP = None
CAMERA_LAST_SCAN = 0
CAMERA_SCAN_INTERVAL = 60
CAMERA_RTSP_PORT = 554
CAMERA_PREFERRED_IPS = ["192.168.11.252"]
CAMERA_STREAM_SAMPLE = None
MEDIA_TELEMETRY_CACHE = {}
MEDIA_TELEMETRY_CACHE_TIME = 0
MEDIA_TELEMETRY_INTERVAL = 1.0
MEDIAMTX_LOG = "/home/orangepi/mmtx/mediamtx.log"

CRSF_FRAMETYPE_RC_CHANNELS_PACKED = 0x16
CRSF_FRAMETYPE_ATTITUDE = 0x1E
CRSF_FRAMETYPE_BF_FM = 0x21
LEVELS = (1000, 1192, 1397, 1602, 1807, 2000)

def ch_to_index(value: int,
                levels: Sequence[int] = LEVELS,
                hysteresis: int = 20,
                prev_index: Optional[int] = None) -> int:
    """
    Map a channel value to an index 0..5 using midpoints between `levels`.
    Adds hysteresis to prevent toggling when value jitters near boundaries.

    - value: channel in us (roughly 1000..2000)
    - hysteresis: deadband in us around boundaries (e.g. 10..30 is typical)
    - prev_index: if provided, enables hysteresis; else simple midpoint mapping.
    """
    if len(levels) != 6:
        raise ValueError("levels must contain exactly 6 values")
    if any(levels[i] >= levels[i+1] for i in range(5)):
        raise ValueError("levels must be strictly increasing")

    # Midpoints between adjacent levels define the boundaries
    b = [(levels[i] + levels[i+1]) / 2.0 for i in range(5)]  # 5 boundaries

    # No previous index -> plain classification by boundaries
    if prev_index is None:
        idx = 0
        for i, boundary in enumerate(b):
            if value >= boundary:
                idx = i + 1
            else:
                break
        return idx

    # With hysteresis: only change index if we cross boundary +/- hysteresis
    idx = max(0, min(5, prev_index))

    # moving down?
    while idx > 0:
        boundary = b[idx - 1]
        if value < boundary - hysteresis:
            idx -= 1
        else:
            break

    # moving up?
    while idx < 5:
        boundary = b[idx]
        if value > boundary + hysteresis:
            idx += 1
        else:
            break

    return idx

def _ticks_to_us(ticks: int) -> int:
    # TBS scaling: center 1500us = 992 ticks; 172->988us; 1811->2012us. :contentReference[oaicite:1]{index=1}
    # Integer form used widely: (ticks - 992) * 5 / 8 + 1500
    return ((ticks - 992) * 5) // 8 + 1500

def is_crsf_rc_channels(frame: bytes) -> bool:
    if len(frame) < 1 + 1 + 1 + 22 + 1:
        return False

    ftype = frame[2]
    return ftype == CRSF_FRAMETYPE_RC_CHANNELS_PACKED

def crsf_rc_channels_decode(frame: bytes) -> List[int]:
    """
    Decode a full CRSF frame containing RC_CHANNELS_PACKED (0x16).
    Expected frame format: [sync][len][type][payload...][crc]
      - len includes type + payload + crc
      - payload for 0x16 is exactly 22 bytes (16 channels packed 11 bits each)

    Returns: list of 16 ints, each clamped to 1000..2000 (microseconds).
    """
    if len(frame) < 1 + 1 + 1 + 22 + 1:
        raise ValueError("Frame too short for RC_CHANNELS_PACKED")

    ftype = frame[2]
    if ftype != CRSF_FRAMETYPE_RC_CHANNELS_PACKED:
        raise ValueError(f"Not RC_CHANNELS_PACKED (got 0x{ftype:02X})")

    # payload starts right after type
    payload = frame[3:3 + 22]
    if len(payload) != 22:
        raise ValueError(f"RC payload must be 22 bytes, got {len(payload)}")

    # Unpack 16x 11-bit little-endian fields
    bitbuf = int.from_bytes(payload, byteorder="little", signed=False)

    channels = []
    for ch in range(16):
        ticks = (bitbuf >> (ch * 11)) & 0x7FF  # 11 bits
        us = _ticks_to_us(ticks)
        # You asked for 1000-2000 specifically:
        if us < 1000: us = 1000
        elif us > 2000: us = 2000
        channels.append(us)

    return channels

def dm_from_ch9(ch9: int) -> str:
    if ch9 < 1300:
        return "STOP"
    if ch9 < 1700:
        return "PONI"
    return "EKO"

def calib_mode(ch13: int) -> bool:
    if ch13 > 1300:
        return True
    else:
        return False

def tcp_open(ip: str, port: int, timeout: float = 0.08) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((ip, port))
        return True
    except:
        return False

def get_eth_ipv4_map_ipcmd():
    try:
        res = subprocess.run(["ip", "-j", "addr", "show"], capture_output=True, text=True, timeout=1, check=True)
        items = json.loads(res.stdout)
    except:
        return {}

    out = {}
    for it in items:
        iface = it.get("ifname")
        if iface == "lo":
            continue
        if "UP" not in set(it.get("flags", [])):
            continue
        for ai in it.get("addr_info", []):
            if ai.get("family") == "inet":
                addr = ai.get("local")
                if addr and addr != "127.0.0.1":
                    out[iface] = addr
                    break
    return out

def get_camera_scan_networks() -> list[ipaddress.IPv4Network]:
    nets = {ipaddress.ip_network("192.168.11.0/24")}
    try:
        for ip in get_eth_ipv4_map_ipcmd().values():
            net = ipaddress.ip_network(ip + "/24", strict=False)
            if str(net.network_address).startswith("192.168."):
                nets.add(net)
    except:
        pass
    return sorted(nets, key=lambda net: int(net.network_address))

def find_camera_ip() -> str | None:
    seen = set()
    for ip in CAMERA_PREFERRED_IPS:
        seen.add(ip)
        if tcp_open(ip, CAMERA_RTSP_PORT, timeout=0.15):
            return ip

    candidates = []
    for net in get_camera_scan_networks():
        for ip in net.hosts():
            ip_s = str(ip)
            if ip_s not in seen:
                seen.add(ip_s)
                candidates.append(ip_s)

    with cf.ThreadPoolExecutor(max_workers=64) as ex:
        futs = {ex.submit(tcp_open, ip, CAMERA_RTSP_PORT): ip for ip in candidates}
        for fut in cf.as_completed(futs):
            try:
                if fut.result():
                    return futs[fut]
            except:
                pass
    return None

def get_camera_ip_cached() -> str | None:
    global CAMERA_IP, CAMERA_LAST_SCAN
    now = time.monotonic()
    if CAMERA_IP and now - CAMERA_LAST_SCAN < CAMERA_SCAN_INTERVAL:
        return CAMERA_IP
    CAMERA_LAST_SCAN = now
    CAMERA_IP = find_camera_ip()
    return CAMERA_IP

def get_camera_ping_ms(ip: str) -> int | None:
    try:
        res = subprocess.run(
            ["ping", "-c", "1", "-W", "1", ip],
            capture_output=True,
            text=True,
            timeout=2,
            check=False
        )
        m = re.search(r"time[=<]([0-9.]+) ms", res.stdout)
        if m:
            return int(round(float(m.group(1))))
    except:
        pass
    return None

def get_mmtx_stream_mbps(ip: str) -> float | None:
    global CAMERA_STREAM_SAMPLE
    try:
        res = subprocess.run(
            ["ss", "-tin", "dst", ip],
            capture_output=True,
            text=True,
            timeout=1,
            check=False
        )
        values = [int(v) for v in re.findall(r"bytes_received:(\d+)", res.stdout)]
        if not values:
            CAMERA_STREAM_SAMPLE = None
            return None
        now = time.monotonic()
        total = max(values)
        prev = CAMERA_STREAM_SAMPLE
        CAMERA_STREAM_SAMPLE = (now, total)
        if prev is None:
            return None
        dt_s = now - prev[0]
        delta = total - prev[1]
        if dt_s <= 0 or delta < 0:
            return None
        return (delta * 8) / dt_s / 1000000.0
    except:
        return None

def get_active_rtsp_ip_from_ss() -> str | None:
    try:
        res = subprocess.run(
            ["ss", "-tin", "dst", ":554"],
            capture_output=True,
            text=True,
            timeout=1,
            check=False
        )
        for line in res.stdout.splitlines():
            if "ESTAB" not in line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            peer = parts[4]
            if peer.endswith(":554"):
                return peer.rsplit(":", 1)[0].strip("[]")
    except:
        pass
    return None

def get_mmtx_quality() -> str | None:
    try:
        with open(MEDIAMTX_LOG, "rb") as h:
            h.seek(0, os.SEEK_END)
            size = h.tell()
            h.seek(max(0, size - 120000))
            lines = h.read().decode(errors="ignore").splitlines()

        active_path = None
        codec_by_path = {}
        for line in lines:
            path_match = re.search(r"\[path ([^\]]+)\].*ready:.*\(([^,)]+)", line)
            if path_match:
                codec_by_path[path_match.group(1)] = path_match.group(2).upper()
            read_match = re.search(r"is reading from path '([^']+)'", line)
            if read_match:
                active_path = read_match.group(1)
            stop_match = re.search(r"\[path ([^\]]+)\].*stopped:", line)
            if stop_match and stop_match.group(1) == active_path:
                active_path = None

        if not active_path and codec_by_path:
            active_path = list(codec_by_path.keys())[-1]
        if active_path:
            return "HD" if active_path.endswith("_hd") else "SD"
    except:
        pass
    return None

def get_media_telemetry() -> dict:
    global MEDIA_TELEMETRY_CACHE, MEDIA_TELEMETRY_CACHE_TIME
    now = time.monotonic()
    if now - MEDIA_TELEMETRY_CACHE_TIME < MEDIA_TELEMETRY_INTERVAL:
        return dict(MEDIA_TELEMETRY_CACHE)

    data = {
        "cam_ip": None,
        "cam_ping_ms": None,
        "mmtx_load": None,
        "mmtx_quality": None,
    }
    ip = get_active_rtsp_ip_from_ss() or get_camera_ip_cached()
    if ip:
        data["cam_ip"] = ip
        data["cam_ping_ms"] = get_camera_ping_ms(ip)
        mbps = get_mmtx_stream_mbps(ip)
        data["mmtx_load"] = None if mbps is None else round(mbps, 1)
        data["mmtx_quality"] = get_mmtx_quality()

    MEDIA_TELEMETRY_CACHE = data
    MEDIA_TELEMETRY_CACHE_TIME = now
    return dict(data)

def is_probably_corrupted_db_error(exc: Exception) -> bool:
    msg = str(exc).lower()
    return (
        isinstance(exc, sqlite3.DatabaseError)
        and (
            "database disk image is malformed" in msg
            or "file is not a database" in msg
            or "malformed" in msg
        )
    )


def remove_sqlite_files(db_path: str) -> None:
    for suffix in ("", "-wal", "-shm", "-journal"):
        path = db_path + suffix
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as e:
            print(f"Warning: failed to remove {path}: {e}")


def open_db_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=5.0)
    conn.row_factory = sqlite3.Row

    # Опціонально корисні pragma
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")

    return conn


def verify_db(conn: sqlite3.Connection) -> None:
    # Перевірка що база взагалі відповідає
    conn.execute("SELECT 1;").fetchone()

    # Швидка перевірка цілісності
    row = conn.execute("PRAGMA quick_check;").fetchone()
    if not row or row[0].lower() != "ok":
        raise sqlite3.DatabaseError(f"SQLite quick_check failed: {row[0] if row else 'no result'}")


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.execute(SCHEMA_SQL)
    conn.execute(INDEX_SQL)
    conn.commit()


def create_fresh_db(db_path: str) -> sqlite3.Connection:
    remove_sqlite_files(db_path)
    conn = open_db_connection(db_path)
    ensure_schema(conn)
    return conn


def init_db(db_path: str = DB_PATH) -> sqlite3.Connection:
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    conn = None
    try:
        conn = open_db_connection(db_path)
        verify_db(conn)
        ensure_schema(conn)

        delete_telemetry_older_than(conn, TELEMETRY_LIFETIME_HR)
        conn.commit()
        return conn

    except Exception as e:
        print(f"DB init failed: {e}")

        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

        # Пересоздаємо базу ТІЛЬКИ якщо вона реально схожа на пошкоджену
        if is_probably_corrupted_db_error(e):
            print("Database looks corrupted. Recreating it...")
            conn = create_fresh_db(db_path)
            return conn

        # Інакше просто пробросити помилку наверх
        raise

def delete_telemetry_older_than(conn, hours: int) -> int:
    """
    Delete telemetry rows older than X hours.
    Returns number of deleted rows.
    """
    if hours <= 0:
        return 0

    cutoff_ts = 1000*int(time.time()) - (hours * 3600)

    cur = conn.execute(
        "DELETE FROM telemetry WHERE timestamp < ?",
        (cutoff_ts,)
    )
    conn.commit()
    return cur.rowcount

def load_last_telemetry(conn, drone_id: int):
    cur = conn.execute(
        "SELECT ID, timestamp, data FROM telemetry "
        "WHERE drone_id = ? ORDER BY ID DESC LIMIT 1",
        (drone_id,)
    )
    row = cur.fetchone()
    if row is None:
        return None

    row_id, ts_int, json_data = row
    data = json.loads(json_data)

    # convert back to datetime if needed
    dt_obj = dt.datetime.utcfromtimestamp(ts_int / 1000)

    return row_id, dt_obj, data

def save_telemetry(conn, drone_id: int, data: dict, active: bool):
    #if when is None:
    when = int(dt.datetime.utcnow().timestamp()*1000)

    json_data = json.dumps(data, ensure_ascii=False)

    #conn.execute("""
    #    INSERT INTO telemetry (drone_id, timestamp, data)
    #    VALUES (?, ?, ?)
    #    ON CONFLICT(drone_id)
    #    DO UPDATE SET
    #        timestamp = excluded.timestamp,
    #        data = excluded.data;
    #""", (drone_id, when, json_data))
    
    conn.execute("""
        INSERT INTO telemetry (drone_id, timestamp, data, active)
        VALUES (?, ?, ?, ?);
    """, (drone_id, when, json_data, 1 if active else 0))

    conn.commit()

def crc8_dvb_s2(data):
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) & 0xFF) ^ 0xD5
            else:
                crc = (crc << 1) & 0xFF
    return crc

def is_valid_elrs_packet(packet: bytes) -> bool:
    """
    Return True if `packet` is a well-formed ELRS/CRSF frame:
      • min length 4 bytes (sync, len, type, crc)
      • sync byte 0xC8 or 0xEE
      • length byte matches actual frame size (len(packet) == length+2)
      • CRC8 over [type + payload] equals the CRC byte
    """
    # Must have at least sync, length, type, and CRC
    if len(packet) < 4:
        return False

    sync = packet[0]
    if sync not in (0xC8, 0xEE):
        return False

    length = packet[1]
    # length covers [TYPE (1) + PAYLOAD (n) + CRC (1)]
    if len(packet) != length + 2:
        return False

    # Extract the bytes to CRC: packet[2:2+(length-1)]
    data = packet[2 : 2 + (length - 1)]
    crc_byte = packet[2 + (length - 1)]

    return crc8_dvb_s2(data) == crc_byte

def crsf_is_attitude(packet: bytes) -> bool:
    """Return True if packet looks like a valid CRSF Attitude (0x1E) frame (basic checks)."""
    if not isinstance(packet, (bytes, bytearray)):
        return False
    if len(packet) < 3:
        return False

    frame_len = packet[1]
    if frame_len < 2:  # must at least contain type+crc
        return False

    total_len = frame_len + 2  # addr + len + (type+payload+crc)
    if len(packet) < total_len:
        return False

    if packet[2] != CRSF_FRAMETYPE_ATTITUDE:
        return False

    payload_len = frame_len - 2
    return payload_len == 6  # pitch(2) + roll(2) + yaw(2)

def crsf_is_bf_fm(packet: bytes) -> bool:
    if not isinstance(packet, (bytes, bytearray)):
        return False
    if len(packet) < 3:
        return False

    frame_len = packet[1]
    if frame_len < 2:  # must at least contain type+crc
        return False

    total_len = frame_len + 2  # addr + len + (type+payload+crc)
    if len(packet) < total_len:
        return False

    if packet[2] != CRSF_FRAMETYPE_BF_FM:
        return False

    payload_len = frame_len - 2
    return payload_len > 0

def crsf_bf_fm_decode(frame: bytes) -> str:
    if frame[2] != 0x21:
        return None
    payload = frame[3:-1]
    return payload.split(b'\x00')[0].decode(errors="ignore")

def crsf_attitude_decode(packet: bytes):
    """
    Decode CRSF Attitude (0x1E) frame and return (pitch_deg, yaw_deg, roll_deg).

    Frame payload order is: pitch, roll, yaw (int16, big-endian), LSB=0.0001 rad. :contentReference[oaicite:2]{index=2}
    """
    if not crsf_is_attitude(packet):
        raise ValueError("Not a CRSF 0x1E Attitude frame (or incomplete)")

    frame_len = packet[1]
    payload_len = frame_len - 2
    payload_start = 3
    payload = packet[payload_start:payload_start + payload_len]  # 6 bytes

    pitch_raw = int.from_bytes(payload[0:2], byteorder="big", signed=True)
    roll_raw  = int.from_bytes(payload[2:4], byteorder="big", signed=True)
    yaw_raw   = int.from_bytes(payload[4:6], byteorder="big", signed=True)

    # LSB = 0.0001 rad
    rad_per_lsb = 1e-4
    deg_per_lsb = rad_per_lsb * (180.0 / math.pi)

    pitch_deg = pitch_raw * deg_per_lsb
    roll_deg  = roll_raw  * deg_per_lsb
    yaw_deg   = yaw_raw   * deg_per_lsb

    # return in the order you asked: pitch, yaw, roll
    return (pitch_deg, yaw_deg, roll_deg)

def is_elrs_batt(packet: bytes) -> bool | None:
    SYNC_BYTE = 0xC8
    TYPE_BATT = 0x08

    sync   = packet[0]
    if sync != SYNC_BYTE:
        return False

    ftype = packet[2]
    if ftype != TYPE_BATT:
        return False
    
    return True

def elrs_batt_decode(packet: bytes) -> float:
    # Minimal sanity check: addr (0), length (1), type (2), voltage hi/lo (3,4), crc (last)
    if len(packet) < 6:
        raise ValueError("CRSF packet too short")

    frame_type = packet[2]
    if frame_type != 0x08:
        raise ValueError(f"Not a battery sensor frame (got type 0x{frame_type:02X})")

    # First two bytes of payload are voltage (big-endian)
    raw_voltage = (packet[3] << 8) | packet[4]

    # Convert from 0.1 V units to millivolts
    #voltage_mv = raw_voltage * 100
    voltage_mv = raw_voltage

    return raw_voltage / 10
    
def is_elrs_gps(packet: bytes) -> dict | None:
    SYNC_BYTE = 0xC8
    TYPE_GPS = 0x02

    sync   = packet[0]
    if sync != SYNC_BYTE:
        return False

    ftype = packet[2]
    if ftype != TYPE_GPS:
        return False
    
    return True

def parse_elrs_gps(packet: bytes) -> dict | None:
    # Minimum packet: [SYNC][LEN][TYPE][...][CRC]
    if len(packet) < 4:
        return None

    SYNC_BYTE  = 0xC8
    TYPE_GPS   = 0x02      # CRSF_FRAMETYPE_GPS :contentReference[oaicite:0]{index=0}
    PAYLOAD_SZ = 15        # degrees*1e7 (4)+lon*1e7 (4)+gs*2+hdg*2+alt*2+sat*1 = 15 :contentReference[oaicite:1]{index=1}

    if packet[0] != SYNC_BYTE:
        return None

    length = packet[1]
    # length = TYPE(1) + PAYLOAD_SZ + CRC(1) = PAYLOAD_SZ + 2
    if length != PAYLOAD_SZ + 2 or len(packet) != length + 2:
        return None

    if packet[2] != TYPE_GPS:
        return None

    # Extract and unpack the payload
    payload = packet[3:3+PAYLOAD_SZ]
    lat_raw, lng_raw, gs_raw, hdg_raw, alt_raw, sats = struct.unpack(">iiHHHB", payload)

    # Convert to human units
    latitude   = lat_raw / 1e7
    longitude  = lng_raw / 1e7
    groundspeed= gs_raw  / 10.0       # km/h
    heading    = hdg_raw/ 100.0       # degrees
    altitude   = alt_raw - 1000       # meters (offset +1000m) :contentReference[oaicite:2]{index=2}

    return {
        "latitude":     round(latitude, 7),
        "longitude":    round(longitude,7),
        "groundspeed":  groundspeed,
        "heading":      heading,
        "altitude":     altitude,
        "satellites":   sats
    }
       

def read_frame(ser):
    # wait for sync (0xC8 downlink / 0xEE uplink)
    while True:
        sync = ser.read(1)
        if not sync: return None
        if sync[0] in (0xC8, 0xEE):
            break

    length_b = ser.read(1)
    if not length_b: return None
    length = length_b[0]
    body = ser.read(length)
    if len(body) != length:
        return None

    # verify CRC
    if crc8_dvb_s2(body[:-1]) != body[-1]:
        return None

    return sync + length_b + body  # full frame as bytes

#targets_lock
def reload_targets(reset_idx=False):
    global TARGETS
    global TARGETS_TIME
    global ACTIVE_TARGET
    global TARGET_IP

    if reset_idx:
        ACTIVE_TARGET = 0
    
    TARGETS = []
    targets_data = None
    if os.path.isfile(TARGETS_PATH):
        with open(TARGETS_PATH, "r", encoding="utf-8") as f:
            targets_data = json.load(f)
        TARGETS_TIME = os.path.getmtime(TARGETS_PATH)
    if targets_data and 'drones' in targets_data and targets_data['drones']:
        for drone_data in targets_data['drones']:
            drone_type = DEFAULT_DRONE_TYPE
            if drone_data:
                drone_id = int(drone_data['droneId'])
                if 'droneType' in drone_data and drone_data['droneType']:
                    drone_type = drone_data['droneType']
                mac = ":".join(f"{b:02X}" for b in drone_id.to_bytes(4, byteorder="big"))
                TARGETS.append({'IP': drone_data['ipAddress'], 'ID': drone_id, 'MAC': mac, 'TYPE': drone_type})
            else:
                TARGETS.append({'IP': None, 'ID': 0, 'MAC': '00:00:00:00', 'TYPE': drone_type})
    
    print('TARGETS:', TARGETS)
    if ACTIVE_TARGET < len(TARGETS):
        TARGET_IP = TARGETS[ACTIVE_TARGET]['IP'] if TARGETS else None
    else:
        TARGET_IP = None

def reload_console_active():
    global TARGETS
    global TARGETS_TIME
    global ACTIVE_TARGET
    global TARGET_IP
    global switch_console_target_time
    try:
        with open(CONSOLE_TARGET_PATH, 'r') as file:
            droneId = int(file.read().strip())
        if TARGETS:
            target_idx = ACTIVE_TARGET
            for _target_idx_tmp in range(len(TARGETS)):
                _target = TARGETS[_target_idx_tmp]
                if _target and _target['ID'] == droneId:
                    target_idx = _target_idx_tmp
            if target_idx != ACTIVE_TARGET or TARGET_IP != TARGETS[target_idx]['IP']:
                ACTIVE_TARGET = target_idx
                TARGET_IP     = TARGETS[ACTIVE_TARGET]['IP']
        #print('SWITCH TO', droneId, target_idx)
    except:
        return
    switch_console_target_time = os.path.getmtime(CONSOLE_TARGET_PATH)

def init_():
    global ser
    global sock
    
    # load targets
    reload_targets(True)
    
    for UART_PORT in UART_PORTS:
        ok = False
        try:
            ser = serial.Serial(
              UART_PORT,
              baudrate=UART_BAUD,
              bytesize=serial.EIGHTBITS,
              parity=serial.PARITY_NONE,
              stopbits=serial.STOPBITS_ONE,
              timeout=0.1)
            print(f"Listening for CRSF on {UART_PORT}")
            ok = True
        except Exception as e:
            print(f"UART read error from {UART_PORT}:", e)
            time.sleep(1)
        if ok: break
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('', UDP_PORT))

def finish_():
    global ser
    global sock
    ser.close()
    sock.close()

def decode_foxy_state(state):
    return {
        "F1":        bool(state & (1 << 0)),
        "F2":        bool(state & (1 << 1)),
        "MD":       (state >> 2) & 0x07,
        "FS":       (state >> 5) & 0x07,
        "VT":       (state >> 8) & 0x07,
        "power":    (state >> 11) & 0x03,
        "BM":       bool(state & (1 << 13)),
        "is_timer": bool(state & (1 << 14)),
        "MC2":      bool(state & (1 << 15)),
    }

def decode_volya_state(state: int):
    return {
        "arm":  bool(state & (1 << 0)),
        "park":    bool(state & (1 << 1)),
        "reverse": bool(state & (1 << 2)),
        "gear":    (state >> 3) & 0x03,   # 2 bits
        "mode":    (state >> 5) & 0x03,   # 2 bits
        "moving": bool(state & (1 << 7)),
        "brake_assist": bool(state & (1 << 8)),
    }

def targets_poller():
    global TARGETS_PATH
    global TARGETS_TIME
    while True:
        if os.path.isfile(TARGETS_PATH):
            t = os.path.getmtime(TARGETS_PATH)
            if t != TARGETS_TIME:
                time.sleep(2)
                with targets_lock:
                    reload_targets()
        if os.path.isfile(CONSOLE_TARGET_PATH):
            t = os.path.getmtime(CONSOLE_TARGET_PATH)
            if t != switch_console_target_time:
                with targets_lock:
                    reload_console_active()
        time.sleep(1)

def udp_heartbeats():
    global sock
    global TARGETS
    global ACTIVE_TARGET
    
    pkt = bytes([0x6A, ])
    while True:
        _targets = []
        with targets_lock:
            if TARGETS:
                for idx in range(len(TARGETS)):
                    TARGET = TARGETS[idx]
                    if TARGET['IP'] and TARGET['IP'] not in _targets:
                        _targets.append(TARGET['IP'])
        for target_ip in _targets:
            try:
                sock.sendto(pkt, (target_ip, TARGET_PORT))
            except Exception as e:
                print("Socket write error:", e)
                time.sleep(0.2)
        time.sleep(2)

def udp_server():
    global sock
    global ser
    global last_gps_lat, last_gps_lng
    global TARGETS
    global ACTIVE_TARGET
    global _last_cleanup
    global last_speed, last_dist, is_calib_mode
    
    conn = init_db(DB_PATH)
    #last = load_last_telemetry(conn, drone_id)
    #telemetry = dict()
    #if last:
    #    row_id, last_ts, data = last
    #    if data is not None:
    #        telemetry = data
    #        print("Loaded telemetry from DB:", telemetry)
    #if not telemetry:
    #    print("Empty telemetry")
    
    print(f"[UDP] Listening on port {UDP_PORT}")
    
    while True:
        now = int(dt.datetime.utcnow().timestamp()*1000)
        pkt, addr = sock.recvfrom(2048)
        if not pkt:
            continue

        if pkt[0] == 0x6A: # heartbeat
            mac = pkt[1:5]
            drone_id = struct.unpack(">I", mac)[0]
            try:
                with open(HB_FILE + str(drone_id), 'w') as _:
                    pass
            except:
                pass
            #print('heartbeat from ', drone_id)
        if pkt[0] == 0x79:
            mac = pkt[1:5]
            drone_id = struct.unpack(">I", mac)[0]
            #print('MAC:', ':'.join(f"{b:02X}" for b in mac), '   ID:', drone_id)
            payload = pkt[5:]
            valid = is_valid_elrs_packet(payload)
            #print(f"[UDP] ← {len(payload)} bytes from {addr}, forwarding to serial", ("VALID" if valid else "INVALID"))
            #if not valid:
            #    print(' '.join(f"{b:02X}" for b in payload))
            #bus.i2c_rdwr(i2c_msg.write(I2C_ADDR, pkt))
            
            if valid and COPY_IP:
                try:
                    sock.sendto(pkt, (COPY_IP, TARGET_PORT))
                except Exception as e:
                    print("Socket copy write error:", e)
                    time.sleep(0.2)
            
            now = time.time()
            if now - _last_cleanup >= CLEANUP_INTERVAL:
                _last_cleanup = now
                delete_telemetry_older_than(conn, TELEMETRY_LIFETIME_HR)
            
            if valid:
                do_send = True
                
                idx_match = False
                drone_type = DEFAULT_DRONE_TYPE
                with targets_lock:
                    if TARGETS:
                        for idx in range(len(TARGETS)):
                            TARGET = TARGETS[idx]
                            if TARGET['ID'] == drone_id:
                                if ACTIVE_TARGET == idx:
                                    idx_match = True
                                drone_type = TARGET['TYPE']
                                break
                try:
                    with open(SLAVE_FILE, 'w') as _:
                        pass
                except:
                    pass
                
                telemetry = dict()
                # check if Batt data (vehicle is online)
                if is_elrs_batt(payload):
                    telemetry['type'] = 'batt'
                    telemetry['batt_v'] = elrs_batt_decode(payload)
                    save_telemetry(conn, drone_id, telemetry, idx_match)
                elif crsf_is_attitude(payload):
                    telemetry['type'] = 'att'
                    angles = crsf_attitude_decode(payload)
                    telemetry['pitch'] = round(angles[0], 2)
                    telemetry['yaw'] = round(angles[1], 2)
                    telemetry['roll'] = round(angles[2], 2)
                    save_telemetry(conn, drone_id, telemetry, idx_match)
                elif crsf_is_bf_fm(payload):
                    telemetry['type'] = 'mode'
                    telemetry['mode'] = crsf_bf_fm_decode(payload) or "?"
                    save_telemetry(conn, drone_id, telemetry, idx_match)
                elif is_elrs_gps(payload):
                    gps = parse_elrs_gps(payload)
                    #if gps and gps['satellites'] == 0 and (drone_type == DRONE_TYPE_FOXY or drone_type == DRONE_TYPE_VOLYA):
                    #    do_send = False
                    if gps:
                        gps_lat = gps['latitude']
                        gps_lng = gps['longitude']
                        #if (gps_lat == 0 and gps_lng == 0 and gps['satellites'] == 11):
                        if (gps_lat == 0 and gps_lng == 0 and gps['satellites'] == 11 or gps['satellites'] == 12 and drone_type == DRONE_TYPE_FOXY):
                            # telemetry from foxy
                            telemetry['type'] = 'state'
                            if (is_calib_mode):
                                telemetry['speed'] = last_speed
                                telemetry['dist'] = last_dist
                            else:
                                telemetry['speed'] = gps['heading']
                                telemetry['dist'] = gps['groundspeed'] * 100.0
                                last_speed = gps['heading']
                                last_dist = gps['groundspeed'] * 100.0
                            state = decode_foxy_state(gps['altitude'] + 1000)
                            telemetry['power'] = state['power']
                            telemetry['fs'] = state['FS']
                            telemetry['f1'] = state['F1']
                            telemetry['f2'] = state['F2']
                            telemetry['vt'] = state['VT']
                            telemetry['bm'] = state['BM']
                            telemetry['is_timer'] = state['is_timer']
                            telemetry['mc2'] = state['MC2']
                            telemetry['sd'] = gps['satellites'] == 12
                            telemetry['dm'] = last_dm
                            telemetry.update(get_media_telemetry())
                            telemetry['md'] = state['MD']
                            telemetry['md_str'] = 'MANUAL'
                            if (state['MD'] == 1):
                                telemetry['md_str'] = 'TIMER 5'
                            elif (state['MD'] == 2):
                                telemetry['md_str'] = 'TIMER 10'
                            elif (state['MD'] == 3):
                                telemetry['md_str'] = 'TIMER 15'
                            elif (state['MD'] == 4):
                                telemetry['md_str'] = 'TIMER 20'
                            elif (state['MD'] == 5):
                                telemetry['md_str'] = 'TIMER 30'
                            save_telemetry(conn, drone_id, telemetry, idx_match)
                            #print(telemetry)
                        elif (gps['satellites'] > 99 and drone_type == DRONE_TYPE_VOLYA):
                            telemetry['type'] = 'state'
                            telemetry['speed'] = gps['heading']
                            telemetry['dist'] = gps['groundspeed'] * 100.0
                            state = decode_volya_state(gps['altitude'] + 1000)
                            telemetry.update(state)
                            telemetry.update(get_media_telemetry())
                            print(telemetry)
                            save_telemetry(conn, drone_id, telemetry, idx_match)
                        else:
                            # не передаємо GPS на пульт - некоректно відобразиться на віджеті
                            if (drone_type == DRONE_TYPE_FOXY or drone_type == DRONE_TYPE_VOLYA): do_send = False
                            telemetry.update(gps)
                            telemetry['type'] = 'gps'
                            save_telemetry(conn, drone_id, telemetry, idx_match)
                            #print(telemetry)
                if do_send and idx_match: ser.write(payload)

def elrs_poller():
    global ser
    global sock
    global TARGET_IP
    global TARGETS
    global ACTIVE_TARGET
    global elrs_p_target
    global last_dm
    global is_calib_mode

    while True:
        try:
            frame = read_frame(ser)
        except Exception as e:
            print("I2C error", e)
            time.sleep(0.2)
            continue
        if frame and is_valid_elrs_packet(frame):
            if is_crsf_rc_channels(frame):
                try:
                    with open(ELRS_FILE, 'w') as _:
                        pass
                except:
                    pass
                channels = crsf_rc_channels_decode(frame)
                last_dm = dm_from_ch9(channels[8])
                is_calib_mode = calib_mode(channels[12])
                with targets_lock:
                    if TARGETS:
                        target_idx = 0
                        if elrs_p_target == None:
                            elrs_p_target = target_idx
                        if target_idx != elrs_p_target:
                            elrs_p_target = target_idx
                            target_idx = max(0, min(target_idx, len(TARGETS) - 1))
                            if target_idx != ACTIVE_TARGET or TARGET_IP != TARGETS[target_idx]['IP']:
                                #print('elrs switch to', target_idx, TARGET_IP, TARGETS[target_idx]['ID'])
                                ACTIVE_TARGET = target_idx
                                TARGET_IP     = TARGETS[ACTIVE_TARGET]['IP']
            # send via UDP
            _TARGETS = None
            _TARGET_IP = None
            _ACTIVE_TARGET = None
            with targets_lock:
                _TARGETS = TARGETS
                _TARGET_IP = TARGET_IP
                _ACTIVE_TARGET = ACTIVE_TARGET
            if _TARGETS and _ACTIVE_TARGET < len(_TARGETS) and _TARGET_IP:
                packet = PREFIX_BYTE + frame
                try:
                    sock.sendto(packet, (_TARGET_IP, TARGET_PORT))
                except Exception as e:
                    print("Socket write error:", e)
                    time.sleep(0.2)
                #print(f"Sent {len(packet)} bytes → {TARGET_IP}:{TARGET_PORT}")
        else:
            if frame:
                print(f"Bad packet {len(frame)}")
            time.sleep(0.005)

if __name__ == "__main__":
    time.sleep(10)
    init_()
    t1 = threading.Thread(target=udp_server, daemon=True)
    t2 = threading.Thread(target=elrs_poller, daemon=True)
    t3 = threading.Thread(target=targets_poller, daemon=True)
    t4 = threading.Thread(target=udp_heartbeats, daemon=True)
    t1.start()
    t2.start()
    t3.start()
    t4.start()
    print("Bridge running; Ctrl-C to quit")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        finish_()
