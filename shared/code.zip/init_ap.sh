#!/bin/bash

# sudo check

if [[ "$EUID" -ne 0 ]]; then
  echo "This script must be run as root. Use: sudo $0"
  exit 1
fi

systemctl disable hostapd
systemctl disable dnsmasq
systemctl is-enabled hostapd
systemctl is-enabled dnsmasq
systemctl stop hostapd
systemctl stop dnsmasq

nmcli dev set wlan0 managed no

MAC=$(cat /sys/class/net/wlan0/address)
SUFFIX=$(echo $MAC | tr -d ':' | tail -c 9)
SSID="MASTER_$SUFFIX"
SSID="${SSID^^}"

tee /etc/network/interfaces.d/wlan0-ap >/dev/null <<EOF
auto wlan0
iface wlan0 inet static
    address 10.0.1.1
    netmask 255.255.255.0
EOF
systemctl restart networking

tee /etc/hostapd/hostapd.conf >/dev/null <<EOF
interface=wlan0
driver=nl80211

ssid=$SSID

hw_mode=g
channel=6
wmm_enabled=1

auth_algs=1
wpa=2
wpa_passphrase=11111111
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
EOF

tee /etc/dnsmasq.conf >/dev/null <<EOF
interface=wlan0
bind-interfaces

dhcp-range=10.0.1.10,10.0.1.255,255.255.255.0,12h

dhcp-option=3,10.0.1.1
dhcp-option=6,10.0.1.1

server=8.8.8.8
log-dhcp
EOF

sudo sed -i 's|^#DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd

systemctl unmask hostapd
systemctl start dnsmasq
systemctl start hostapd
systemctl disable hostapd
systemctl disable dnsmasq
systemctl is-enabled hostapd
systemctl is-enabled dnsmasq

sysctl -w net.ipv4.ip_forward=1
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-ap-router.conf
sysctl --system
cat /proc/sys/net/ipv4/ip_forward
iptables -t nat -A POSTROUTING -o end0 -j MASQUERADE
iptables -A FORWARD -i end0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i wlan0 -o end0 -j ACCEPT
