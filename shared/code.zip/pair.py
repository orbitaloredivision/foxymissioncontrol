#!/usr/bin/env python3

import os
import sys
import argparse
import json
import select
import socket
import struct
import time

HB_FILE  = '/dev/shm/hb_'
timeout = 10.0
interval = 0.1  # seconds

def split_broadcast_args(values):
    """
    Accept repeated args and/or comma-separated lists:
      --broadcast 192.168.0.255 --broadcast 10.8.0.255
      --broadcast 192.168.0.255,10.8.0.255
    """
    out = []
    for v in values:
        for part in v.split(","):
            part = part.strip()
            if part:
                out.append(part)
    # de-dupe while preserving order
    seen = set()
    unique = []
    for ip in out:
        if ip not in seen:
            seen.add(ip)
            unique.append(ip)
    return unique

def mac_to_str(b: bytes) -> str:
    return ":".join(f"{x:02X}" for x in b)

def ip_to_str(b: bytes) -> str:
    return ".".join(str(x) for x in b)

def parse_device_packet(data: bytes):
    """
    Expected payload:
      mac[6] + ip[4] + master[1]  => 11 bytes total
    master is treated as bool: 0 = False, non-zero = True
    If packet is longer, only the first 11 bytes are used.
    """
    
    if len(data) < 16:
        return None
    if (data[0] != 0x71):
        return None

    '''
    mac = data[1:7]
    ip = data[7:11]
    targetIp = data[11:15]
    master = bool(data[15])
    crsf_speed, crsf2_speed = struct.unpack_from("<II", data, offset=16)
    '''
    if len(data) == 24:
        FORMAT = "<6B4B4B?II"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = unpacked[15]
        crsf2_speed = unpacked[16]
        dtype = 0
    elif len(data) == 16:
        FORMAT = "<6B4B4B?"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = 420000
        crsf2_speed = 420000
        dtype = 0
    elif len(data) == 25:
        FORMAT = "<6B4B4B?IIB"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = unpacked[15]
        crsf2_speed = unpacked[16]
        dtype = unpacked[17]
    else:
        return None

    if master:
        return None
    drone_id = struct.unpack(">I", mac[2:])[0]
    
    res = {
        "mac": mac_to_str(mac[2:]),
        "ip": ip_to_str(ip),
        "target_ip": ip_to_str(targetIp),
        "drone_id": drone_id,
        "crsf_speed": crsf_speed,
        "crsf2_speed": crsf2_speed
    }
    if dtype == 1: res['type'] = 'volya'
    res['method'] = 'udp'
    return res

def get_drone_id(ip, port = 8888, timeout = 5.0):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        bind_ip = ""
        sock.bind((bind_ip, port))
        sock.setblocking(False)

        # Send discovery byte to all broadcast targets
        try:
            sock.sendto(b"\x70", (ip, port))
        except OSError as e:
            # Don't crash if one interface/broadcast is invalid; just note it.
            # (You can remove this print if you want silence.)
            #print(json.dumps({"send_error": str(e), "broadcast": bcast_ip}))
            return 0

        # Collect replies
        end = time.monotonic() + timeout
        results = []
        seen = set()  # (mac, ip, master)
        while True:
            remaining = end - time.monotonic()
            if remaining <= 0:
                break

            r, _, _ = select.select([sock], [], [], remaining)
            if not r:
                continue

            data, _addr = sock.recvfrom(2048)
            dev = parse_device_packet(data)
            if dev is None:
                continue

            key = (dev["mac"], dev["ip"])
            if key in seen:
                continue
            seen.add(key)
            results.append(dev)
            if dev["ip"] == ip:
                return dev
    finally:
        sock.close()
    return None

def do_pair(port, timeout, slave_ip, target_ip, _id):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    try:
        sock.setblocking(False)

        prefix = 0x6B;
        payload = bytes([prefix]) + socket.inet_aton(target_ip)
        sent = False
        try:
            sock.sendto(payload, (slave_ip, port))
            sent = True
        except OSError as e:
            #print(json.dumps({"result": False, "error": str(e)}))
            return False
        if sent:
            time.sleep(2)
            fname = HB_FILE + str(_id)
            try:
                os.remove(fname)
            except FileNotFoundError:
                pass
            # 2. Wait up to 10 seconds for it to appear
            received = False
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if os.path.exists(fname):
                    received = True
                    break
                time.sleep(interval)
            if received:
                #print(json.dumps({"result": True}))
                return True
            #else:
            #    print(json.dumps({"result": False, "error": "Timeout"}))
    finally:
        sock.close()
    return False

def main():
    ap = argparse.ArgumentParser(description="Set TargetIP via UDP")
    ap.add_argument("--port", type=int, default=1091, help="UDP port to send to (default: 1091)")
    ap.add_argument("--timeout", type=float, default=10.0, help="Seconds to wait for replies (default: 10)")
    ap.add_argument("--slave_ip", help="IP address of a slave")
    #ap.add_argument("--target_ip", help="IP address of a target (this device IP)")
    ap.add_argument(
        "--target_ips",
        action="append",
        default=[],
        help='Target IP(s). Repeat or comma-separate. Example: --target_ips 192.168.0.5 --target_ips 10.8.0.5',
    )
    ap.add_argument("--id", type=int, default=0, help="drone_id")
    args = ap.parse_args()

    dev = get_drone_id(args.slave_ip)
    if not dev:
        print(json.dumps({"result": False, "error": "Can't get drone ID"}))
        sys.exit(0)
    args.id = dev['drone_id']
    
    found = False
    targets = split_broadcast_args(args.target_ips) or []
    if not targets:
        print(json.dumps({"result": False, "error": "No local IP!?"}))
        sys.exit(0)
    for target in targets:
        if do_pair(args.port, args.timeout, args.slave_ip, target, args.id):
            print(json.dumps({"result": True, "local_ip": target, "slave_ip": args.slave_ip, "drone_id": args.id, "crsf_speed": dev["crsf_speed"], "crsf2_speed": dev["crsf2_speed"]}))
            found = True
            break
    if not found:
        print(json.dumps({"result": False, "error": "Timeout"}))

if __name__ == "__main__":
    main()
