#!/usr/bin/env python3
import time
from smbus2 import SMBus
from PIL import Image, ImageSequence

class SSD1309:
    WIDTH  = 128
    HEIGHT = 64
    PAGES  = HEIGHT // 8

    def __init__(self, bus: int = 3, addr: int = 0x3C):
        self.bus  = SMBus(bus)
        self.addr = addr
        self._init_display()

    def _cmd(self, c: int):
        self.bus.write_byte_data(self.addr, 0x00, c)

    def _data(self, buf: list[int]):
        # SMBus block writes limited to 32 bytes
        for i in range(0, len(buf), 32):
            self.bus.write_i2c_block_data(self.addr, 0x40, buf[i:i+32])

    def _init_display(self):
        seq = [
            0xAE,           # DISPLAYOFF
            0x20, 0x00,     # MEMMODE: horizontal
            0xB0,           # PAGEADDR
            0xC8,           # COMSCANDEC
            0x00, 0x10,     # COL addr
            0x40,           # STARTLINE
            0x81, 0x7F,     # CONTRAST
            0xA1,           # SEGREMAP
            0xA6,           # NORMALDISPLAY
            0xA8, 0x3F,     # MUXRATIO
            0xA4,           # DISPLAYALLON_RESUME
            0xD3, 0x00,     # DISPLAYOFFSET
            0xD5, 0x80,     # DISPLAYCLOCKDIV
            0xD9, 0xF1,     # PRECHARGE
            0xDA, 0x12,     # COMPINCONFIG
            0xDB, 0x40,     # VCOMDETECT
            0x8D, 0x14,     # CHARGEPUMP
            0xAF,           # DISPLAYON
        ]
        for c in seq:
            self._cmd(c)
        self.clear()

    def clear(self):
        empty = [0x00] * self.WIDTH
        for page in range(self.PAGES):
            self._cmd(0xB0 + page)
            self._cmd(0x00)
            self._cmd(0x10)
            self._data(empty)

    def display_image(self, img: Image.Image):
        # img must be mode "1", size 128x64
        pix = img.getdata()
        for page in range(self.PAGES):
            self._cmd(0xB0 + page)
            self._cmd(0x00)
            self._cmd(0x10)
            buf = []
            for x in range(self.WIDTH):
                byte = 0
                for bit in range(8):
                    if pix[x + (page*8 + bit)*self.WIDTH]:
                        byte |= (1 << bit)
                buf.append(byte)
            self._data(buf)

def _prepare_frame_resize(frame: Image.Image, invert: bool = False) -> Image.Image:
    """
    Convert arbitrary GIF frame -> 128x64 1-bit image suitable for OLED.
    """
    # Convert to grayscale first, resize, then threshold to 1-bit
    g = frame.convert("L").resize((128, 64), Image.Resampling.LANCZOS)

    # Threshold to 1-bit. Tweak 128 -> higher = fewer white pixels.
    bw = g.point(lambda p: 255 if p > 128 else 0, mode="1")

    if invert:
        # Invert 1-bit: convert to L, invert, back to 1
        bw = bw.convert("L").point(lambda p: 255 - p).convert("1")
    return bw

def _prepare_frame(frame: Image.Image, invert: bool = False) -> Image.Image:
    """
    Center-crop GIF frame to 128x64, then convert to 1-bit.
    No resizing or scaling.
    """
    w, h = frame.size
    target_w, target_h = 128, 64

    if w < target_w or h < target_h:
        raise ValueError(f"GIF frame too small: {frame.size}, need at least 128x64")

    # Center crop
    left   = (w - target_w) // 2
    top    = (h - target_h) // 2
    right  = left + target_w
    bottom = top + target_h

    cropped = frame.crop((left, top, right, bottom))

    # Convert to grayscale → threshold → 1-bit
    bw = cropped.convert("L").point(
        lambda p: 255 if p > 128 else 0,
        mode="1"
    )

    if invert:
        bw = bw.convert("L").point(lambda p: 255 - p).convert("1")

    return bw

def play_gif_on_oled(
    oled: SSD1309,
    gif_path: str,
    fps: float | None = 10.0,   # set None to use GIF per-frame durations
    speed: float = 1.0,         # 1.0 normal, 2.0 twice as fast, 0.5 half speed
    repeat: int = 0,            # 0 = infinite
    invert: bool = False
):
    """
    Plays an animated GIF on the OLED.

    - If fps is not None: each frame delay = (1/fps)/speed
    - If fps is None: uses GIF frame duration (ms) scaled by 1/speed
    - repeat: 0 = infinite, N = play N loops
    """
    im = Image.open(gif_path)

    # Pre-extract frames + durations (so playback is stable)
    frames = []
    durations = []
    for fr in ImageSequence.Iterator(im):
        frames.append(_prepare_frame(fr, invert=invert))
        durations.append(fr.info.get("duration", 100))  # ms default

    if not frames:
        raise ValueError("No frames found in GIF")

    loops_done = 0
    try:
        while True:
            for idx, fr in enumerate(frames):
                oled.display_image(fr)

                if fps is not None:
                    delay_s = (1.0 / float(fps)) / float(speed)
                else:
                    delay_s = (durations[idx] / 1000.0) / float(speed)

                #time.sleep(max(0.0, delay_s))

            if repeat != 0:
                loops_done += 1
                if loops_done >= repeat:
                    break
    finally:
        oled.clear()

def main():
    oled = SSD1309(bus=3, addr=0x3C)

    # Example usage:
    # - 12 fps
    # - infinite loop (repeat=0)
    play_gif_on_oled(
        oled,
        gif_path="demo.gif",
        fps=24.0,
        speed=2.0,
        repeat=0,
        invert=False
    )

if __name__ == "__main__":
    main()
