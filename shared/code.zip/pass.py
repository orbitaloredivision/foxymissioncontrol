#!/usr/bin/env python3

import random
import time
import os

FILE_PATH = "/dev/shm/code"
INTERVAL = 180  # seconds

def write_code():
    code = f"{random.randint(0, 9999):04d}"
    with open(FILE_PATH, "w") as f:
        f.write(code + "\n")

def main():
    # Ensure /dev/shm exists (it always should, but just in case)
    if not os.path.isdir("/dev/shm"):
        raise RuntimeError("/dev/shm does not exist")

    # Write immediately at startup
    write_code()

    # Then update every minute
    while True:
        time.sleep(INTERVAL)
        write_code()

if __name__ == "__main__":
    main()
