#!/bin/bash

WWW_TARGET="8.8.8.8"                # Remote WWW server IP to ping
TIMEOUT_SEC=20                      # Modify this constant as needed
CONS_TARGET="http://localhost"
WWW_SIG="/dev/shm/www"
CONS_SIG="/dev/shm/console"
MAST_SIG="/dev/shm/master"
MMTX_SIG="/dev/shm/mmtx"

echo "Starting WWW watchdog: target=$WWW_TARGET timeout=${TIMEOUT_SEC}s"
while true; do
  if ping -c 1 -W 1 "$WWW_TARGET" > /dev/null; then
    touch $WWW_SIG
  fi

  sleep 1
done &

echo "Starting console watchdog: target=$CONS_TARGET timeout=${TIMEOUT_SEC}s"
while true; do
  w=`curl $CONS_TARGET | grep -i "mission control" | wc -l`
  if [ $w -gt 0 ]; then
    touch $CONS_SIG
  fi

  sleep 5
done &

echo "Start MMTX watchdog"
while true; do
  age=`pgrep -f mediamtx >/dev/null && pgrep -f mediamtx | xargs -n1 ps -o etimes= -p | sort -nr | head -n1 | xargs || echo 0`
  if [ $age -gt 5 ]; then
    touch $MMTX_SIG
  fi

  sleep 5
done &

echo "Start Master watchdog"
while true; do
  age=`pgrep -f master.py >/dev/null && pgrep -f master.py | xargs -n1 ps -o etimes= -p | sort -nr | head -n1 | xargs || echo 0`
  if [ $age -gt 5 ]; then
    touch $MAST_SIG
  fi

  sleep 5
done &

wait
