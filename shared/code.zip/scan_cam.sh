#!/usr/bin/env bash
set -euo pipefail

# Path to your discovery script
SCAN_PY="${SCAN_PY:-./scan_cam.py}"
SLAVE_IP=",${1:-}"

if [ $SLAVE_IP == "," ]; then
  SLAVE_IP=""
fi

# Get all global IPv4 addresses from UP interfaces, excluding loopback.
# Output lines look like: "192.168.0.10/24"
mapfile -t CIDRS < <(
  ip -o -4 addr show up scope global \
  | awk '!/ lo / {print $4}' \
  | sort -u
)

if (( ${#CIDRS[@]} == 0 )); then
  echo "{\"result\": false, \"error\": \"No IP\"}"
  exit 0
fi

# Convert each IP to "X.X.X.255" (simple /24 assumption as requested)
BCASTS=()
for cidr in "${CIDRS[@]}"; do
  ip="${cidr%%/*}"
  # Build X.X.X.255 from X.X.X.Y
  bcast="$(echo "$ip" | awk -F. 'NF==4 {print $1"."$2"."$3"."$4}')"
  if [[ -n "$bcast" ]]; then
    BCASTS+=("$bcast")
  fi
done

# De-duplicate while preserving order
UNIQ_BCASTS=()
declare -A seen=()
for b in "${BCASTS[@]}"; do
  if [[ -z "${seen[$b]+x}" ]]; then
    seen["$b"]=1
    UNIQ_BCASTS+=("$b")
  fi
done

if (( ${#UNIQ_BCASTS[@]} == 0 )); then
  echo "{\"result\": false, \"error\": \"No IP\"}"
  exit 0
fi

BCAST_ARG="$(IFS=,; echo "${UNIQ_BCASTS[*]}")"

exec python3 "$SCAN_PY" --locals "${BCAST_ARG}${SLAVE_IP}"  --user admin --password 123456
