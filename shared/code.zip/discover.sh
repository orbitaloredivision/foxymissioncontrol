#!/usr/bin/env bash
set -euo pipefail

# Path to your discovery script
DISCOVER_PY="${DISCOVER_PY:-./discover.py}"

# Get all global IPv4 addresses from UP interfaces, excluding loopback.
# Output lines look like: "192.168.0.10/24"
mapfile -t CIDRS < <(
  ip -o -4 addr show up scope global \
  | awk '!/ lo / {print $4}' \
  | sort -u
)

if (( ${#CIDRS[@]} == 0 )); then
  echo "No active IPv4 addresses found (nowhere to scan)." >&2
  exit 1
fi

# Convert each IP to "X.X.X.255" (simple /24 assumption as requested)
BCASTS=()
for cidr in "${CIDRS[@]}"; do
  ip="${cidr%%/*}"
  # Build X.X.X.255 from X.X.X.Y
  bcast="$(echo "$ip" | awk -F. 'NF==4 {print $1"."$2"."$3".255"}')"
  if [[ -n "$bcast" ]]; then
    BCASTS+=("$bcast")
  fi
done

# De-duplicate while preserving order
UNIQ_BCASTS=()
declare -A seen=()
for b in "${BCASTS[@]}"; do
  if [[ -z "${seen[$b]+x}" ]]; then
    seen["$b"]=1
    UNIQ_BCASTS+=("$b")
  fi
done

if (( ${#UNIQ_BCASTS[@]} == 0 )); then
  echo "Could not derive any broadcast targets from IPs." >&2
  exit 1
fi

BCAST_ARG="$(IFS=,; echo "${UNIQ_BCASTS[*]}")"

exec python3 "$DISCOVER_PY" --broadcast "$BCAST_ARG"
