#!/usr/bin/env python3
"""
RTSP 554-only camera discovery + optional ONVIF manufacturer/model probe + snapshot URL probe.

Safety:
- No password lists / no guessing.
- Only uses the single credential pair you provide via --user/--password.

Output JSON includes:
- login/password (as provided)
- rtsp probe result
- onvif GetDeviceInformation (best-effort)
- snapshot URL (best-effort)
"""

from __future__ import annotations

import argparse
import base64
import concurrent.futures as cf
import ipaddress
import hashlib
import json
import re
import socket
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Tuple

RTSP_PORT = 554
USER_AGENT = "rtsp-discovery/1.2"

RTSP_PATHS = [
    "/stream0",
    "/stream1",
    "/0",
    "/1",
    "/live.sdp",
    "/Streaming/Channels/101",
    "/Streaming/Channels/1",
    "/h264",
    "/h265",
    "/videoMain",
    "/mpeg4",
]

# ONVIF device_service guesses
ONVIF_PORTS = [80, 8000, 8080, 8899]
ONVIF_PATHS = ["/onvif/device_service", "/onvif/devices"]
ONVIF_TIMEOUT_SEC = 1.2

# Snapshot URL guesses (vendor-dependent)
SNAPSHOT_PORTS = [80, 8080, 8000, 8899]
SNAPSHOT_PATHS = [
    "/snapshot.jpg",
    "/SnapshotJPEG?Resolution=640x480",
    "/cgi-bin/snapshot.cgi",
    "/cgi-bin/jpg/image.cgi",
    "/cgi-bin/currentpic.cgi",
    "/jpg/image.jpg",
    "/image.jpg",
    "/img/snapshot.cgi",
    "/Streaming/channels/1/picture",
    "/Streaming/channels/101/picture",
]
SNAPSHOT_TIMEOUT_SEC = 1.2


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--locals", help="IPs like 192.168.0.5,10.8.0.8 (derive /24 networks)")
    ap.add_argument("--cidrs", help="CIDRs like 192.168.0.0/24,10.8.0.0/24")
    ap.add_argument("--threads", type=int, default=256)
    ap.add_argument("--timeout", type=float, default=0.6, help="RTSP socket timeout seconds")
    ap.add_argument("--max-hosts", type=int, default=4096)
    ap.add_argument("--user", help="RTSP/ONVIF/HTTP username (single credential pair only)")
    ap.add_argument("--password", help="RTSP/ONVIF/HTTP password (single credential pair only)")
    ap.add_argument("--no-onvif", action="store_true", help="Disable ONVIF probing")
    ap.add_argument("--no-snapshot", action="store_true", help="Disable snapshot URL probing")
    return ap.parse_args()


def tcp_open(ip: str, port: int, timeout: float) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((ip, port))
        return True
    except Exception:
        return False


def recv_all(sock: socket.socket, timeout: float, max_bytes: int = 200_000) -> bytes:
    sock.settimeout(timeout)
    data = b""
    while True:
        try:
            part = sock.recv(4096)
            if not part:
                break
            data += part
            if len(data) >= max_bytes:
                break
        except socket.timeout:
            break
        except Exception:
            break
    return data


def rtsp_request(
    ip: str,
    path: str,
    method: str,
    timeout: float,
    user: Optional[str],
    password: Optional[str],
) -> Tuple[int, Dict[str, str], bytes]:
    url = f"rtsp://{ip}:{RTSP_PORT}{path}"
    headers = [
        f"{method} {url} RTSP/1.0",
        "CSeq: 1",
        f"User-Agent: {USER_AGENT}",
    ]

    # Only uses what YOU provide
    if user and password:
        token = base64.b64encode(f"{user}:{password}".encode()).decode()
        headers.append(f"Authorization: Basic {token}")

    headers.append("\r\n")
    payload = "\r\n".join(headers).encode("ascii", "ignore")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        s.connect((ip, RTSP_PORT))
        s.sendall(payload)
        raw = recv_all(s, timeout=timeout)

    status = 0
    m = re.search(br"RTSP/\d\.\d\s+(\d{3})", raw)
    if m:
        status = int(m.group(1))

    head, _, body = raw.partition(b"\r\n\r\n")
    hdrs: Dict[str, str] = {}
    for line in head.split(b"\r\n")[1:]:
        if b":" in line:
            k, v = line.split(b":", 1)
            hdrs[k.decode("latin1").strip().lower()] = v.decode("latin1").strip()

    return status, hdrs, body


def parse_sdp(body: bytes) -> Dict:
    text = body.decode(errors="ignore")
    codecs = set()
    name = None
    controls = []

    for line in text.splitlines():
        line = line.strip()
        if line.startswith("s=") and not name:
            name = line[2:].strip()
        if line.startswith("a=control:"):
            controls.append(line.split(":", 1)[1].strip())
        if line.startswith("a=rtpmap:"):
            m = re.search(r"\s([A-Za-z0-9]+)/", line)
            if m:
                codecs.add(m.group(1).upper())

    return {
        "session_name": name,
        "codecs": sorted(codecs),
        "controls": controls[:20],
        "sdp_preview": text[:600],
    }


def probe_rtsp(ip: str, timeout: float, user: Optional[str], password: Optional[str]) -> Optional[Dict]:
    for path in RTSP_PATHS:
        try:
            st_opt, _, _ = rtsp_request(ip, path, "OPTIONS", timeout, user, password)
            if st_opt in (200, 401, 404):
                st_desc, hdrs, body = rtsp_request(ip, path, "DESCRIBE", timeout, user, password)
                out: Dict = {
                    "port": RTSP_PORT,
                    "path": path,
                    "options_status": st_opt,
                    "describe_status": st_desc,
                    "www_authenticate": hdrs.get("www-authenticate"),
                }
                if st_desc == 200 and body:
                    out["sdp"] = parse_sdp(body)
                return out
        except Exception:
            continue
    return None


def onvif_build_opener(ip: str, user: str, password: str) -> urllib.request.OpenerDirector:
    pwd_mgr = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pwd_mgr.add_password(None, f"http://{ip}", user, password)
    pwd_mgr.add_password(None, f"http://{ip}/", user, password)
    digest = urllib.request.HTTPDigestAuthHandler(pwd_mgr)
    basic = urllib.request.HTTPBasicAuthHandler(pwd_mgr)
    opener = urllib.request.build_opener(digest, basic)
    opener.addheaders = [
        ("User-Agent", USER_AGENT),
        ("Accept", "application/soap+xml, text/xml, */*"),
    ]
    return opener


def onvif_get_device_information(ip: str, user: Optional[str], password: Optional[str]) -> Optional[Dict]:
    if not (user and password):
        return None

    soap = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
  <s:Body>
    <tds:GetDeviceInformation/>
  </s:Body>
</s:Envelope>""".encode("utf-8")

    opener = onvif_build_opener(ip, user, password)

    for port in ONVIF_PORTS:
        for path in ONVIF_PATHS:
            url = f"http://{ip}:{port}{path}"
            req = urllib.request.Request(
                url=url,
                data=soap,
                method="POST",
                headers={"Content-Type": "application/soap+xml; charset=utf-8"},
            )
            try:
                with opener.open(req, timeout=ONVIF_TIMEOUT_SEC) as resp:
                    raw = resp.read(200_000)
                root = ET.fromstring(raw)

                def find_text(local: str) -> Optional[str]:
                    for el in root.iter():
                        if el.tag.endswith("}" + local) or el.tag == local:
                            if el.text and el.text.strip():
                                return el.text.strip()
                    return None

                info = {
                    "url": url,
                    "manufacturer": find_text("Manufacturer"),
                    "model": find_text("Model"),
                    "firmware_version": find_text("FirmwareVersion"),
                    "serial_number": find_text("SerialNumber"),
                    "hardware_id": find_text("HardwareId"),
                }
                if info["model"] or info["manufacturer"]:
                    return info
            except Exception:
                continue

    return None


def looks_like_jpeg(data: bytes) -> bool:
    # JPEG magic bytes: FF D8 ... FF D9 (end might be missing in truncated reads)
    return len(data) >= 3 and data[0:2] == b"\xff\xd8"


def probe_snapshot_url(ip: str, user: Optional[str], password: Optional[str]) -> Optional[Dict]:
    """
    Tries common snapshot URLs and returns the first that looks like a JPEG.
    Uses Digest/Basic auth only if creds provided.
    """
    opener = None
    if user and password:
        opener = onvif_build_opener(ip, user, password)  # same handlers work for plain HTTP

    for port in SNAPSHOT_PORTS:
        for path in SNAPSHOT_PATHS:
            url = f"http://{ip}:{port}{path}"
            try:
                req = urllib.request.Request(url=url, method="GET", headers={"User-Agent": USER_AGENT})
                if opener:
                    resp = opener.open(req, timeout=SNAPSHOT_TIMEOUT_SEC)
                else:
                    resp = urllib.request.urlopen(req, timeout=SNAPSHOT_TIMEOUT_SEC)

                with resp:
                    ctype = resp.headers.get("Content-Type", "")
                    data = resp.read(80_000)

                # Accept either proper header or raw JPEG magic
                if "image/jpeg" in ctype.lower() or looks_like_jpeg(data):
                    return {
                        "url": url,
                        "content_type": ctype,
                        "bytes_preview_len": len(data),
                    }
            except Exception:
                continue

    return None


def derive_networks(locals_csv: Optional[str], cidrs_csv: Optional[str]) -> List[ipaddress.IPv4Network]:
    nets: List[ipaddress.IPv4Network] = []
    if locals_csv:
        for ip_s in locals_csv.split(","):
            ip_s = ip_s.strip()
            if ip_s:
                net = ipaddress.ip_network(f"{ip_s}/24", strict=False)
                if net.version == 4:
                    nets.append(net)
    if cidrs_csv:
        for c in cidrs_csv.split(","):
            c = c.strip()
            if c:
                net = ipaddress.ip_network(c, strict=False)
                if net.version == 4:
                    nets.append(net)
    uniq = sorted({str(n): n for n in nets}.values(), key=lambda n: int(n.network_address))
    return uniq


def expand_hosts(nets: List[ipaddress.IPv4Network], max_hosts: int) -> List[str]:
    out: List[str] = []
    for net in nets:
        for ip in net.hosts():
            out.append(str(ip))
            if len(out) >= max_hosts:
                return out
    return out


def scan_host(ip: str, timeout: float, user: Optional[str], password: Optional[str],
              do_onvif: bool, do_snapshot: bool) -> Optional[Dict]:
    if not tcp_open(ip, RTSP_PORT, timeout):
        return None

    rtsp_info = probe_rtsp(ip, timeout, user, password)

    result = {
        "ip": ip,
        "rtsp_port": RTSP_PORT,
        "login": user,
        "password": password,
        "rtsp": rtsp_info,
        "onvif": None,
        "snapshot": None,
    }

    # If RTSP looks alive, snapshot/ONVIF often exist; probe best-effort.
    if rtsp_info is not None:
        if do_onvif:
            result["onvif"] = onvif_get_device_information(ip, user, password)
        if do_snapshot:
            result["snapshot"] = probe_snapshot_url(ip, user, password)

    return result


def main() -> int:
    args = parse_args()
    nets = derive_networks(args.locals, args.cidrs)
    if not nets:
        print("[]")
        return 0

    hosts = expand_hosts(nets, max_hosts=args.max_hosts)

    results: List[Dict] = []
    do_onvif = not args.no_onvif
    do_snapshot = not args.no_snapshot

    with cf.ThreadPoolExecutor(max_workers=max(1, args.threads)) as ex:
        futs = [ex.submit(scan_host, ip, args.timeout, args.user, args.password, do_onvif, do_snapshot) for ip in hosts]
        for fut in cf.as_completed(futs):
            r = fut.result()
            if r:
                results.append(r)

    results.sort(key=lambda x: ipaddress.ip_address(x["ip"]))
    for res in results:
        if 'rtsp' in res and 'onvif' in res and res['rtsp'] and res['onvif']:
            model = res['onvif']['model'] if 'model' in res['onvif'] and res['onvif']['model'] else None
            man = res['onvif']['manufacturer'] if 'manufacturer' in res['onvif'] and res['onvif']['manufacturer'] else None
            path = res['rtsp']['path'] if 'path' in res['rtsp'] and res['rtsp']['path'] else None
            if model == 'PA4' and man == 'Vatilon' and path == '/stream0':
                res['rtsp']['path_hd'] = '/stream1'
        if 'rtsp' in res and ('onvif' not in res or res['onvif'] is None):
            #generate fake onvif
            res['onvif'] = {
                "url": "http://"+res['ip'],
                "manufacturer": "Unknown",
                "model": "",
                "firmware_version": "",
                "serial_number": hashlib.md5((res['ip']+json.dumps(res['rtsp'])).encode('utf-8')).hexdigest(),
                "hardware_id": ""
            }
    print(json.dumps(results, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
