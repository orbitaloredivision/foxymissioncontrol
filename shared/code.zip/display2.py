#!/usr/bin/python3
import os
import sys
import time
import socket
import fcntl
import struct
import json
import subprocess
from smbus2 import SMBus
from PIL import Image, ImageDraw, ImageFont, ImageSequence

IFACE="end0"
SLAVE_SIG="/dev/shm/slave"
WWW_SIG="/dev/shm/www"
ELRS_SIG="/dev/shm/elrs"
CONS_SIG="/dev/shm/console"
MMTX_SIG="/dev/shm/mmtx"
MAST_SIG="/dev/shm/master"
PASS_SIG="/dev/shm/code"

def get_eth_ipv4_map_ipcmd():
    """
    Build {iface: ipv4} using `ip -j addr show`:
    - excludes 'lo'
    - excludes interfaces that are DOWN
    - excludes interfaces without an IPv4 address
    - excludes non-ethernet (checks link_type == 'ether')
    Linux only.
    """
    cmd = ["ip", "-j", "addr", "show"]
    res = subprocess.run(cmd, capture_output=True, text=True, check=True)
    items = json.loads(res.stdout)

    out = {}

    for it in items:
        iface = it.get("ifname")
        if iface == "lo":
            continue

        # filter out not-up
        flags = set(it.get("flags", []))
        if "UP" not in flags:
            continue

        # filter out non-ethernet (wifi still appears as ether, but you asked "ethernet devices";
        # link_type is still 'ether' for wifi. If you strictly want wired only, see note below.)
        #if it.get("link_type") != "ether":
        #    continue

        ipv4 = None
        for ai in it.get("addr_info", []):
            if ai.get("family") == "inet":
                addr = ai.get("local")
                if addr and addr != "127.0.0.1":
                    ipv4 = addr
                    break

        if ipv4:
            out[iface] = ipv4

    return out

def get_mac_suffix(interface: str) -> str:
    """
    Reads the MAC address from sysfs and returns its last two hex digits.
    E.g. "b8:27:eb:45:12:34" → "34"
    """
    try:
        with open(f"/sys/class/net/{interface}/address") as f:
            mac = f.read().strip()
            return str(mac.split(':')[-2])+str(mac.split(':')[-1])
    except FileNotFoundError:
        raise ValueError(f"Interface {interface!r} not found")

def get_ip_address(interface: str) -> str:
    """
    Uses an ioctl call to fetch the IPv4 address assigned to the given interface.
    Returns string like "192.168.1.42".
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # SIOCGIFADDR = 0x8915
    ifr = struct.pack('256s', interface[:15].encode('utf-8'))
    try:
        res = fcntl.ioctl(sock.fileno(), 0x8915, ifr)
        ip_bytes = res[20:24]
        return socket.inet_ntoa(ip_bytes)
    except OSError:
        raise ValueError(f"No IPv4 address assigned to {interface!r}")

def get_file_age_secs(path: str) -> int:
    """
    Return the file’s age in whole seconds (time since last modification).
    If the file doesn’t exist or can’t be stat-ed, returns sys.maxsize.
    """
    try:
        mtime = os.path.getmtime(path)
    except (OSError, FileNotFoundError):
        return sys.maxsize
    return int(time.time() - mtime)

class SSD1309:
    WIDTH  = 128
    HEIGHT = 64
    PAGES  = HEIGHT // 8

    def __init__(self, bus: int = 3, addr: int = 0x3C):
        self.bus  = SMBus(bus)
        self.addr = addr
        self._init_display()

    def _cmd(self, c: int):
        self.bus.write_byte_data(self.addr, 0x00, c)

    def _data(self, buf: list[int]):
        for i in range(0, len(buf), 32):
            chunk = buf[i:i+32]
            self.bus.write_i2c_block_data(self.addr, 0x40, chunk)

    def _init_display(self):
        seq = [
            0xAE, 0x20,0x00, 0xB0, 0xC8, 0x00,0x10, 0x40,
            0x81,0x7F, 0xA1, 0xA6, 0xA8,0x3F, 0xA4,
            0xD3,0x00, 0xD5,0x80, 0xD9,0xF1, 0xDA,0x12,
            0xDB,0x40, 0x8D,0x14, 0xAF
        ]
        for cmd in seq:
            self._cmd(cmd)
        self.clear()

    def clear(self):
        empty = [0x00] * self.WIDTH
        for page in range(self.PAGES):
            self._cmd(0xB0 + page)
            self._cmd(0x00)
            self._cmd(0x10)
            self._data(empty)

    def display_image(self, img: Image.Image):
        pix = img.getdata()
        for page in range(self.PAGES):
            self._cmd(0xB0 + page)
            self._cmd(0x00)
            self._cmd(0x10)
            buf = []
            for x in range(self.WIDTH):
                byte = 0
                for bit in range(8):
                    if pix[x + (page*8 + bit)*self.WIDTH]:
                        byte |= (1 << bit)
                buf.append(byte)
            self._data(buf)

def _prepare_frame_resize(frame: Image.Image, invert: bool = False) -> Image.Image:
    """
    Convert arbitrary GIF frame -> 128x64 1-bit image suitable for OLED.
    """
    # Convert to grayscale first, resize, then threshold to 1-bit
    g = frame.convert("L").resize((128, 64), Image.Resampling.LANCZOS)

    # Threshold to 1-bit. Tweak 128 -> higher = fewer white pixels.
    bw = g.point(lambda p: 255 if p > 128 else 0, mode="1")

    if invert:
        # Invert 1-bit: convert to L, invert, back to 1
        bw = bw.convert("L").point(lambda p: 255 - p).convert("1")
    return bw

def _prepare_frame(frame: Image.Image, invert: bool = False) -> Image.Image:
    """
    Center-crop GIF frame to 128x64, then convert to 1-bit.
    No resizing or scaling.
    """
    w, h = frame.size
    target_w, target_h = 128, 64

    if w < target_w or h < target_h:
        raise ValueError(f"GIF frame too small: {frame.size}, need at least 128x64")

    # Center crop
    left   = (w - target_w) // 2
    top    = (h - target_h) // 2
    right  = left + target_w
    bottom = top + target_h

    cropped = frame.crop((left, top, right, bottom))

    # Convert to grayscale → threshold → 1-bit
    bw = cropped.convert("L").point(
        lambda p: 255 if p > 128 else 0,
        mode="1"
    )

    if invert:
        bw = bw.convert("L").point(lambda p: 255 - p).convert("1")

    return bw

def play_gif_on_oled(
    oled: SSD1309,
    gif_path: str,
    fps: float | None = 10.0,   # set None to use GIF per-frame durations
    speed: float = 1.0,         # 1.0 normal, 2.0 twice as fast, 0.5 half speed
    repeat: int = 0,            # 0 = infinite
    invert: bool = False
):
    """
    Plays an animated GIF on the OLED.

    - If fps is not None: each frame delay = (1/fps)/speed
    - If fps is None: uses GIF frame duration (ms) scaled by 1/speed
    - repeat: 0 = infinite, N = play N loops
    """
    im = Image.open(gif_path)

    # Pre-extract frames + durations (so playback is stable)
    frames = []
    durations = []
    for fr in ImageSequence.Iterator(im):
        frames.append(_prepare_frame(fr, invert=invert))
        durations.append(fr.info.get("duration", 100))  # ms default

    if not frames:
        raise ValueError("No frames found in GIF")

    loops_done = 0
    try:
        while True:
            for idx, fr in enumerate(frames):
                oled.display_image(fr)

                if fps is not None:
                    delay_s = (1.0 / float(fps)) / float(speed)
                else:
                    delay_s = (durations[idx] / 1000.0) / float(speed)

                #time.sleep(max(0.0, delay_s))

            if repeat != 0:
                loops_done += 1
                if loops_done >= repeat:
                    break
    finally:
        oled.clear()

class GridDisplay:
    ROWS = 6
    COLS = 3

    def __init__(self, oled: SSD1309, interval_ms: int = 500):
        self.oled       = oled
        self.interval   = interval_ms / 1000.0
        self.cells      = [
            [ {'text': '', 'blink': False} for _ in range(self.COLS) ]
            for _ in range(self.ROWS)
        ]
        #self.font       = ImageFont.load_default()
        self.font = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            10
        )
        self.blink_on   = True
        self.last_draw  = time.monotonic()
        self.cell_w     = oled.WIDTH  // self.COLS
        self.cell_h     = oled.HEIGHT // self.ROWS

    def set_cell(self, row: int, col: int, text: str, blink: bool = False):
        if 0 <= row < self.ROWS and 0 <= col < self.COLS:
            self.cells[row][col]['text']  = text
            self.cells[row][col]['blink'] = blink

    def update(self):
        now = time.monotonic()
        if now - self.last_draw < self.interval:
            return
        self.last_draw = now
        self.blink_on = not self.blink_on

        img  = Image.new("1", (self.oled.WIDTH, self.oled.HEIGHT))
        draw = ImageDraw.Draw(img)

        for r in range(self.ROWS):
            for c in range(self.COLS):
                cell = self.cells[r][c]
                if cell['text'] and (not cell['blink'] or self.blink_on):
                    x = c * self.cell_w
                    y = r * self.cell_h
                    draw.text((x, y), cell['text'], font=self.font, fill=255)

        self.oled.display_image(img)


def update_cells(grid: GridDisplay):
    for row in range(grid.ROWS-1):
        grid.set_cell(row+2, 0, '', blink=False)
    try:
        ips = get_eth_ipv4_map_ipcmd()
        
        row = 2
        for iface in sorted(ips):
            ip = ips[iface]
            grid.set_cell(row, 0, iface+': '+ip, blink=False)
            row = row+1
            if row >= grid.ROWS:
                break
    except:
        pass
    
    err_elrs = get_file_age_secs(ELRS_SIG) > 15
    err_slave = get_file_age_secs(SLAVE_SIG) > 15
    err_www = get_file_age_secs(WWW_SIG) > 15
    err_cons = get_file_age_secs(CONS_SIG) > 15
    err_mmtx = get_file_age_secs(MMTX_SIG) > 15
    err_mast = get_file_age_secs(MAST_SIG) > 15
    
    err = ''
    if err_elrs: err += 'E'
    if err_slave: err += 'S'
    if err_www: err += 'I'
    if err_cons: err += 'C'
    if err_mmtx: err += 'M'
    if err_mast: err += 'R'
    
    grid.set_cell(5, 0, err+'_', blink=True)
    try:
        code = ''
        with open(PASS_SIG, 'r') as h:
            code = h.read().strip()
        grid.set_cell(5, 2, '   -'+code+'-', blink=False)
    except:
        pass

def main():
    oled = SSD1309(bus=3, addr=0x3C)
    
    play_gif_on_oled(
        oled,
        gif_path="animation/load4.gif",
        fps=24.0,
        speed=2.0,
        repeat=1,
        invert=False
    )
    
    grid = GridDisplay(oled, interval_ms=500)

    #mac = get_mac_suffix(IFACE).upper()
    
    # initial cell setup if needed
    grid.set_cell(0, 0, "FOXY MISSION CONTROL", blink=False)
    #grid.set_cell(0, 1, " "+mac+" >", blink=False)
    #grid.set_cell(0, 2, "", blink=False)
    
    #grid.set_cell(5, 0, ".", blink=True)

    last_update = 0
    update_interval = 5.0  # seconds

    try:
        while True:
            now = time.monotonic()
            # every second, call our update_cells()
            if now - last_update >= update_interval:
                update_cells(grid)
                last_update = now

            grid.update()
            time.sleep(0.01)
    except KeyboardInterrupt:
        oled.clear()


if __name__ == "__main__":
    main()