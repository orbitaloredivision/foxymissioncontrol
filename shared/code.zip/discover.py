#!/usr/bin/env python3

import argparse
import json
import select
import socket
import struct
import time
import asyncio
import urllib.request
from bleak import BleakScanner, BleakClient

SERVICE_UUID = "9f3a2c1e-7b44-4d8a-bc9e-1a6c0f8d7b21"
RX_UUID      = "e2b1f4a9-6c3d-4a7e-9f52-8a0b1c2d3e44"
TX_UUID      = "7c8d9e10-2a3b-4c5d-8e9f-a1b2c3d4e5f6"
NAME_PREFIX = ["XXX_SLAVE_", "XXX_VOLYA_"]

SERVER = "http://185.233.117.8:8080"
TIMEOUT = 1800  # 30 minutes

def get_active_ips(timeout_sec: int):
    url = f"{SERVER}/list?timeout={timeout_sec}"

    with urllib.request.urlopen(url, timeout=5) as resp:
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status}")

        data = json.loads(resp.read().decode("utf-8"))

    # Extract IPs
    return [entry["ip"] for entry in data.get("active", [])]

def mac_to_str(b: bytes) -> str:
    return ":".join(f"{x:02X}" for x in b)

def ip_to_str(b: bytes) -> str:
    return ".".join(str(x) for x in b)

def parse_device_packet(data: bytes):
    """
    Expected payload:
      mac[6] + ip[4] + master[1]  => 11 bytes total
    master is treated as bool: 0 = False, non-zero = True
    If packet is longer, only the first 11 bytes are used.
    """
    
    if len(data) < 16:
        return None
    if (data[0] != 0x71):
        return None

    '''
    mac = data[1:7]
    ip = data[7:11]
    targetIp = data[11:15]
    master = bool(data[15])
    crsf_speed, crsf2_speed = struct.unpack_from("<II", data, offset=16)
    '''
    if len(data) == 24:
        FORMAT = "<6B4B4B?II"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = unpacked[15]
        crsf2_speed = unpacked[16]
        dtype = 0
    elif len(data) == 16:
        FORMAT = "<6B4B4B?"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = 420000
        crsf2_speed = 420000
        dtype = 0
    elif len(data) == 25:
        FORMAT = "<6B4B4B?IIB"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = unpacked[15]
        crsf2_speed = unpacked[16]
        dtype = unpacked[17]
    else:
        return None

    if master:
        return None
    drone_id = struct.unpack(">I", mac[2:])[0]
    
    res = {
        "mac": mac_to_str(mac[2:]),
        "ip": ip_to_str(ip),
        "target_ip": ip_to_str(targetIp),
        "drone_id": drone_id,
        "crsf_speed": crsf_speed,
        "crsf2_speed": crsf2_speed
    }
    if dtype == 1: res['type'] = 'volya'
    res['method'] = 'udp'
    return res

def split_broadcast_args(values):
    """
    Accept repeated args and/or comma-separated lists:
      --broadcast 192.168.0.255 --broadcast 10.8.0.255
      --broadcast 192.168.0.255,10.8.0.255
    """
    out = []
    for v in values:
        for part in v.split(","):
            part = part.strip()
            if part:
                out.append(part)
    # de-dupe while preserving order
    seen = set()
    unique = []
    for ip in out:
        if ip not in seen:
            seen.add(ip)
            unique.append(ip)
    return unique

async def query_bt_device(d, n):
    buf = bytearray()
    ev = asyncio.Event()

    def cb(_h, data: bytearray):
        buf.extend(data)
        if b"\n" in buf:
            ev.set()

    async with BleakClient(d) as c:
        await c.start_notify(TX_UUID, cb)
        await c.write_gatt_char(RX_UUID, b"GET_IP\n", response=True)
        await asyncio.wait_for(ev.wait(), timeout=5)
        await c.stop_notify(TX_UUID)

    reply = bytes(buf).split(b"\n", 1)[0].decode(errors="replace")
    if reply:
        parts = reply.split(" ")
        len_match = len(parts) == 5 or len(parts) == 7
        if not len_match or parts[0] != 'OK' or parts[3] != '0':
            return None
        
        crsf_speed = 420000
        crsf2_speed = 420000
        if len(parts) == 7:
            if len(parts[6]) != 8:
                return None
            crsf_speed = int(parts[4])
            crsf2_speed = int(parts[5])
            mac = bytes.fromhex(parts[6])
        else:
            if len(parts[4]) != 8:
                return None
            mac = bytes.fromhex(parts[4])
        drone_id = struct.unpack(">I", mac)[0]
        res = {
            "mac": mac_to_str(mac),
            "ip": parts[1],
            "target_ip": parts[2],
            "drone_id": drone_id,
            "crsf_speed": crsf_speed,
            "crsf2_speed": crsf2_speed
        }
        if 'VOLYA' in n: res['type'] = 'volya'
        res['method'] = 'bt'
        return res
    return None

async def main():
    ap = argparse.ArgumentParser(description="Broadcast UDP discovery to multiple broadcast IPs and collect replies.")
    ap.add_argument("--port", type=int, default=8888, help="UDP port to send to / listen on (default: 8888)")
    ap.add_argument("--timeout", type=float, default=5.0, help="Seconds to wait for replies (default: 5)")
    ap.add_argument(
        "--broadcast",
        action="append",
        default=[],
        help='Broadcast IP(s). Repeat or comma-separate. Example: --broadcast 192.168.0.255 --broadcast 10.8.0.255',
    )
    ap.add_argument(
        "--bind",
        default="",
        help="Optional local interface IP to bind for sending/receiving (e.g. 192.168.0.10). Default: all interfaces.",
    )
    args = ap.parse_args()

    www_ips = []
    try:
        www_ips = get_active_ips(TIMEOUT)
    except Exception as e:
        pass

    broadcasts = split_broadcast_args(args.broadcast) or ["255.255.255.255"]

    results = []
    seen = set()  # (mac, ip, master)

    #devs = await BleakScanner.discover(timeout=6)
    #targets = [d for d in devs if (d.name or "").startswith(NAME_PREFIX)]
    
    targets = []
    names = []

    def cb(device, adv):
        name = adv.local_name or device.name or ""
        in_prefix = False
        for p in NAME_PREFIX:
            if name.startswith(p):
                in_prefix = True
                break
        if in_prefix and name not in names:
            targets.append((device, name))
            names.append(name)

    scanner = BleakScanner(detection_callback=cb)
    await scanner.start()
    await asyncio.sleep(8)
    await scanner.stop()
    
    for d,n in targets:
        try:
            dev = await query_bt_device(d, n)
            if dev:
                key = (dev["mac"], dev["ip"])
                if key in seen:
                    continue
                seen.add(key)
                results.append(dev)
        except Exception as e:
            pass
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        bind_ip = args.bind if args.bind else ""
        sock.bind((bind_ip, args.port))
        sock.setblocking(False)

        # Send discovery byte to all IPs from WWW
        for bcast_ip in www_ips:
            try:
                sock.sendto(b"\x70", (bcast_ip, args.port))
            except OSError as e:
                # Don't crash if one interface/broadcast is invalid; just skip it.
                pass

        # Send discovery byte to all broadcast targets
        for bcast_ip in broadcasts:
            if bcast_ip in www_ips:
                continue
            try:
                sock.sendto(b"\x70", (bcast_ip, args.port))
            except OSError as e:
                # Don't crash if one interface/broadcast is invalid; just skip it.
                pass

        # Collect replies
        end = time.monotonic() + args.timeout

        while True:
            remaining = end - time.monotonic()
            if remaining <= 0:
                break

            r, _, _ = select.select([sock], [], [], remaining)
            if not r:
                continue

            data, _addr = sock.recvfrom(2048)
            dev = None
            try:
                dev = parse_device_packet(data)
            except Exception as e:
                pass
            if dev is None:
                continue

            key = (dev["mac"], dev["ip"])
            if key in seen:
                continue
            if dev["ip"] in www_ips:
                dev["method"] = "www"
            seen.add(key)
            results.append(dev)
    finally:
        sock.close()
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
