#!/usr/bin/env bash

SLAVE_IP=$1
NEW_IP=$2
CRSF_SPEED=$3
CRSF2_SPEED=$4

python3 ./drone_conf.py --slave_ip $SLAVE_IP --new_ip $NEW_IP --crsf_speed $CRSF_SPEED --crsf2_speed $CRSF2_SPEED
