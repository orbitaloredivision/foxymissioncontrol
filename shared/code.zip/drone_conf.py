#!/usr/bin/env python3

import os
import sys
import argparse
import json
import select
import socket
import struct
import time

def mac_to_str(b: bytes) -> str:
    return ":".join(f"{x:02X}" for x in b)

def ip_to_str(b: bytes) -> str:
    return ".".join(str(x) for x in b)

def get_drone_id(sock, ip, port = 8888, timeout = 5.0):
    if 1:
        # Send discovery byte to all broadcast targets
        try:
            sock.sendto(b"\x70", (ip, port))
        except OSError as e:
            raise Exception('Can\'t send discover packet')

        # Collect replies
        end = time.monotonic() + timeout
        results = []
        seen = set()  # (mac, ip, master)
        while True:
            remaining = end - time.monotonic()
            if remaining <= 0:
                break

            r, _, _ = select.select([sock], [], [], remaining)
            if not r:
                continue

            data, _addr = sock.recvfrom(2048)
            dev = parse_device_packet(data)
            if dev is None:
                continue

            key = (dev["mac"], dev["ip"])
            if key in seen:
                continue
            seen.add(key)
            results.append(dev)
            if dev["ip"] == ip:
                return dev["drone_id"]
    return 0

def parse_device_packet(data: bytes):
    """
    Expected payload:
      mac[6] + ip[4] + master[1]  => 11 bytes total
    master is treated as bool: 0 = False, non-zero = True
    If packet is longer, only the first 11 bytes are used.
    """
    
    if len(data) < 16:
        return None
    if (data[0] != 0x71):
        return None

    '''
    mac = data[1:7]
    ip = data[7:11]
    targetIp = data[11:15]
    master = bool(data[15])
    crsf_speed, crsf2_speed = struct.unpack_from("<II", data, offset=16)
    '''
    if len(data) == 24:
        FORMAT = "<6B4B4B?II"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = unpacked[15]
        crsf2_speed = unpacked[16]
    elif len(data) == 16:
        FORMAT = "<6B4B4B?"
        unpacked = struct.unpack_from(FORMAT, data, offset=1)
        mac = bytearray(unpacked[0:6])
        ip = unpacked[6:10]
        targetIp = unpacked[10:14]
        master = unpacked[14]
        crsf_speed = 420000
        crsf2_speed = 420000
    else:
        return None

    if master:
        return None
    drone_id = struct.unpack(">I", mac[2:])[0]

    return {
        "mac": mac_to_str(mac[2:]),
        "ip": ip_to_str(ip),
        "target_ip": ip_to_str(targetIp),
        "drone_id": drone_id,
        "crsf_speed": crsf_speed,
        "crsf2_speed": crsf2_speed,
        "method": "udp"
    }

def do_configure(port, timeout, slave_ip, new_ip, crsf_speed, crsf2_speed):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock_disc = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    try:
        sock.setblocking(False)
        
        sock_disc.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock_disc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        bind_ip = ""
        sock_disc.bind((bind_ip, 8888))
        sock_disc.setblocking(False)

        drone_id = get_drone_id(sock_disc, slave_ip, 8888, timeout)
        if drone_id <= 0:
            raise Exception('Can\'t find drone ID')

        prefix = 0x6C;
        payload = bytes([prefix]) + socket.inet_aton(new_ip) + struct.pack("<II", crsf_speed, crsf2_speed)
        sent = False
        try:
            sock.sendto(payload, (slave_ip, port))
            sent = True
        except OSError as e:
            raise Exception('Can\'t send conf packet')
        if sent:
            # Collect replies
            end = time.monotonic() + timeout
            results = []
            seen = set()  # (mac, ip, master)
            while True:
                remaining = end - time.monotonic()
                if remaining <= 0:
                    break

                r, _, _ = select.select([sock_disc], [], [], remaining)
                if not r:
                    continue

                data, _addr = sock_disc.recvfrom(2048)
                dev = parse_device_packet(data)
                if dev is None:
                    continue
                
                key = (dev["mac"], dev["ip"])
                if key in seen:
                    continue
                seen.add(key)
                results.append(dev)
                if dev["drone_id"] == drone_id:
                    return dev
    finally:
        sock.close()
        sock_disc.close()
    return None

def main():
    ap = argparse.ArgumentParser(description="Set TargetIP via UDP")
    ap.add_argument("--port", type=int, default=1091, help="UDP port to send to (default: 1091)")
    ap.add_argument("--timeout", type=float, default=10.0, help="Seconds to wait for replies (default: 10)")
    ap.add_argument("--slave_ip", help="IP address of a slave")
    ap.add_argument("--new_ip", help="New IP address of a slave")
    ap.add_argument("--crsf_speed", type=int, default=0, help="Crossfire speed (to drone)")
    ap.add_argument("--crsf2_speed", type=int, default=0, help="Backup Crossfire speed")
    args = ap.parse_args()

    try:
        data = do_configure(args.port, args.timeout, args.slave_ip, args.new_ip, args.crsf_speed, args.crsf2_speed)
    except Exception as e:
        print(json.dumps({"result": False, "error": str(e)}))
        return
    if data:
        data['result'] = True
        print(json.dumps(data))
    else:
        print(json.dumps({"result": False, "error": "Timeout"}))

if __name__ == "__main__":
    main()
